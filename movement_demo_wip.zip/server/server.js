// ============================================================
// server.js -- secure (wss://) multiplayer server for the movement
// test chamber. Lives in its own server/ directory -- this is Node
// server software, separate from the browser client in src/.
// ============================================================
//
// What this does:
//   - Serves one or more "rooms", one per map file in ./maps/*.json
//     (the exact same JSON a player's in-game editor "save build to
//     JSON" produces -- entities + optional mod scripts).
//   - Players connect over wss://, pick a username + a map (by typing
//     its file name, minus ".json"), and get relayed to everyone else
//     in that same map: positions, and a basic text chat.
//   - The map editor is disabled for everyone by default once
//     connected. An operator sitting at this server's own console can
//     type `admin <player_name>` to grant that one player's client
//     permission to open the editor again.
//   - A map's mod scripts (see ../src/mod_docs.md) can be marked
//     "onstart", in which case this server itself runs them the moment
//     it boots (or the moment that map is first touched, if it wasn't
//     preloaded -- see runOnstartScripts()), in a small server-side
//     sandbox with its own API (ticks, chat broadcast, player list,
//     namespaced storage) -- separate from the browser-side API
//     client scripts get. See "SERVER-SIDE MOD SCRIPTS" below.
//
// What this is NOT:
//   - A hardened, public-internet-hostile-traffic-proof game server.
//     There's no authentication beyond "type a username", no
//     authoritative anti-cheat (clients self-report position), and the
//     server-side script sandbox (Node's `vm` module) restricts *scope*,
//     not a real security boundary against a determined attacker with
//     code execution. Treat this the way you'd treat a Minecraft server
//     you run for friends: fine to open up to people you trust, put
//     behind a firewall/allowlist otherwise, and never load a map file
//     (especially one with onstart scripts) you haven't read yourself.
//
// Setup:
//   cd server && npm install
//   npm run cert            # or bring your own cert.pem/key.pem
//   npm start
// Config is via environment variables (see the top of main() below).
"use strict";

const fs = require("fs");
const path = require("path");
const https = require("https");
const vm = require("vm");
const readline = require("readline");
const WebSocket = require("ws");

// ---------------------------------------------------------------------
// config
// ---------------------------------------------------------------------
const PORT = parseInt(process.env.PORT || "8443", 10);
const CERT_PATH = process.env.CERT_PATH || path.join(__dirname, "cert.pem");
const KEY_PATH = process.env.KEY_PATH || path.join(__dirname, "key.pem");
const MAPS_DIR = process.env.MAPS_DIR || path.join(__dirname, "maps");
const MAX_PLAYERS = parseInt(process.env.MAX_PLAYERS || "64", 10);
const MAX_PAYLOAD_BYTES = 64 * 1024;
const TICK_MS = 200;                 // server-side mod script tick rate
const HEARTBEAT_MS = 30000;          // ws ping/pong housekeeping
const STATE_MIN_INTERVAL_MS = 33;    // ignore a client's position updates faster than ~30/s
const CHAT_MAX_LEN = 300;
const CHAT_WINDOW_MS = 4000;
const CHAT_MAX_IN_WINDOW = 5;
const USERNAME_RE = /^[A-Za-z0-9_\-]{1,20}$/;
const MAPNAME_RE = /^[A-Za-z0-9_\-]{1,64}$/;

function log(msg){ console.log(`[${new Date().toISOString()}] ${msg}`); }

// ---------------------------------------------------------------------
// map loading
// ---------------------------------------------------------------------
function listMapNames(){
  try {
    return fs.readdirSync(MAPS_DIR)
      .filter(f => f.toLowerCase().endsWith(".json"))
      .map(f => f.slice(0, -5));
  } catch (err){
    log("could not read maps dir " + MAPS_DIR + ": " + err.message);
    return [];
  }
}

function loadMapFile(name){
  if (!MAPNAME_RE.test(name)) return null;
  // MAPNAME_RE already forbids "/", "\", "..", etc, but path.basename +
  // a directory containment check is cheap insurance against path
  // traversal regardless.
  const fname = path.basename(name) + ".json";
  const full = path.join(MAPS_DIR, fname);
  if (!full.startsWith(path.resolve(MAPS_DIR))) return null;
  if (!fs.existsSync(full)) return null;
  try {
    const raw = fs.readFileSync(full, "utf8");
    const data = JSON.parse(raw);
    if (!data || !Array.isArray(data.entities)) return null;
    if (!Array.isArray(data.scripts)) data.scripts = [];
    return data;
  } catch (err){
    log(`failed to parse map "${name}": ${err.message}`);
    return null;
  }
}

// ---------------------------------------------------------------------
// rooms -- one per map name currently in use (or preloaded for onstart)
// ---------------------------------------------------------------------
const rooms = new Map(); // mapName -> room

function createRoom(mapName, mapData){
  const room = {
    mapName,
    mapData,
    players: new Map(),  // id -> player
    tickHandlers: [],
    storage: {},          // per-script-id storage for server-side mods
    bus: {},               // server-side cross-script event bus
    tickInterval: null,
  };
  room.tickInterval = setInterval(() => {
    for (const fn of room.tickHandlers.slice()) {
      try { fn(); } catch (err){ log(`[mod:${mapName}] tick handler error: ${err.message}`); }
    }
  }, TICK_MS);
  rooms.set(mapName, room);
  runOnstartScripts(room);
  return room;
}

function getOrCreateRoom(mapName){
  const existing = rooms.get(mapName);
  if (existing) return existing;
  const mapData = loadMapFile(mapName);
  if (!mapData) return null;
  return createRoom(mapName, mapData);
}

// ---------------------------------------------------------------------
// SERVER-SIDE MOD SCRIPTS
// ---------------------------------------------------------------------
// A script in a map's "scripts" array with "onstart": true runs here, on
// the server, the moment its room exists -- either right at server boot
// (see main(), which preloads any map containing an onstart script) or,
// for maps nobody flagged for preload, the moment a room is first created
// (first player to name that map). Either way it is NOT gated on any
// player actually joining -- "onstart" means the server itself runs it,
// unconditionally, as soon as it's in a position to.
//
// This is a different runtime than the client-side one in src/mods.js:
// no `player`/`createEntity`/DOM, because there IS no browser here. What
// it gets instead: ticking, chat broadcast, the connected player list,
// and namespaced storage -- the things a persistent server-side process
// (an economy tick, a scheduled announcement, a scoreboard) actually
// needs. See mod_docs.md's "server-side (onstart) scripts" section.
function buildServerModAPI(room, script){
  const sid = script.id;
  if (!room.storage[sid]) room.storage[sid] = {};
  const store = room.storage[sid];
  return {
    version: 1,
    mapName: room.mapName,
    scriptName: script.name,
    onTick(fn){ if (typeof fn === "function") room.tickHandlers.push(fn); },
    log(msg){ log(`[mod:${room.mapName}/${script.name}] ${msg}`); },
    chat: {
      broadcast(text){
        broadcastToRoom(room, { type: "chat", id: null, username: "SERVER", text: String(text).slice(0, CHAT_MAX_LEN), ts: Date.now() });
      },
    },
    players: {
      list(){ return [...room.players.values()].map(p => ({ id: p.id, username: p.username, isAdmin: p.isAdmin })); },
    },
    store: {
      get(key, fallback){ return (key in store) ? store[key] : fallback; },
      set(key, value){ store[key] = value; },
      all(){ return JSON.parse(JSON.stringify(store)); },
    },
    bus: {
      emit(event, payload){
        const hs = room.bus[event];
        if (!hs) return;
        for (const h of hs.slice()) {
          try { h(payload); } catch (err){ log(`[mod:${room.mapName}] bus("${event}") handler error: ${err.message}`); }
        }
      },
      on(event, handler){ if (typeof handler === "function") (room.bus[event] || (room.bus[event] = [])).push(handler); },
    },
  };
}

function runServerScript(room, script){
  const api = buildServerModAPI(room, script);
  const sandbox = { API: api, console };
  const context = vm.createContext(sandbox);
  try {
    vm.runInContext(script.code, context, { filename: `${room.mapName}/${script.name}.js`, timeout: 2000 });
    log(`[mod:${room.mapName}/${script.name}] onstart script ran`);
  } catch (err){
    log(`[mod:${room.mapName}/${script.name}] ERROR: ${err.message}`);
  }
}

function runOnstartScripts(room){
  const scripts = Array.isArray(room.mapData.scripts) ? room.mapData.scripts : [];
  for (const s of scripts) {
    if (!s || !s.onstart || typeof s.code_b64 !== "string") continue;
    let code;
    try { code = Buffer.from(s.code_b64, "base64").toString("utf8"); } catch (err){ continue; }
    runServerScript(room, { id: s.id || s.name || "script", name: s.name || "script", code });
  }
}

// ---------------------------------------------------------------------
// player <-> room messaging helpers
// ---------------------------------------------------------------------
function send(ws, msg){
  if (ws.readyState !== WebSocket.OPEN) return;
  try { ws.send(JSON.stringify(msg)); } catch (err){ /* ignore -- socket likely closing */ }
}
function broadcastToRoom(room, msg, exceptId){
  const data = JSON.stringify(msg);
  for (const p of room.players.values()) {
    if (exceptId && p.id === exceptId) continue;
    if (p.ws.readyState === WebSocket.OPEN) p.ws.send(data);
  }
}

function uniqueUsername(room, base){
  let name = base, n = 2;
  const taken = new Set([...room.players.values()].map(p => p.username.toLowerCase()));
  while (taken.has(name.toLowerCase())) { name = `${base}_${n}`; n++; }
  return name;
}

// ---------------------------------------------------------------------
// connection handling
// ---------------------------------------------------------------------
let playerIdCounter = 0;
function nextPlayerId(){ return "p" + (++playerIdCounter); }

function totalPlayers(){
  let n = 0;
  for (const room of rooms.values()) n += room.players.size;
  return n;
}

function handleConnection(ws){
  ws.isAlive = true;
  ws.on("pong", () => { ws.isAlive = true; });

  let player = null; // set once join succeeds
  let chatTimes = [];
  let lastStateAt = 0;

  send(ws, { type: "hello", maps: listMapNames() });

  ws.on("message", (raw) => {
    if (raw.length > MAX_PAYLOAD_BYTES) return; // belt-and-suspenders; ws server option also caps this
    let msg;
    try { msg = JSON.parse(raw); } catch (err){ return; }
    if (!msg || typeof msg.type !== "string") return;

    if (msg.type === "join"){
      if (player) return; // already joined
      if (totalPlayers() >= MAX_PLAYERS){ send(ws, { type: "error", message: "server is full" }); return; }

      const rawName = typeof msg.username === "string" ? msg.username.trim() : "";
      if (!USERNAME_RE.test(rawName)){
        send(ws, { type: "error", message: "username must be 1-20 characters: letters, numbers, _ or -" });
        return;
      }
      const mapName = typeof msg.map === "string" ? msg.map.trim() : "";
      if (!MAPNAME_RE.test(mapName)){
        send(ws, { type: "error", message: "invalid map name", maps: listMapNames() });
        return;
      }
      const room = getOrCreateRoom(mapName);
      if (!room){
        send(ws, { type: "error", message: `no map named "${mapName}" on this server`, maps: listMapNames() });
        return;
      }

      const username = uniqueUsername(room, rawName);
      player = {
        id: nextPlayerId(), ws, username, isAdmin: false,
        pos: [0, 0, 80], yaw: 0, pitch: 0, room,
      };
      room.players.set(player.id, player);

      send(ws, {
        type: "joined",
        id: player.id,
        username,
        map: room.mapData,
        players: [...room.players.values()].filter(p => p.id !== player.id)
          .map(p => ({ id: p.id, username: p.username, isAdmin: p.isAdmin, pos: p.pos, yaw: p.yaw, pitch: p.pitch })),
      });
      broadcastToRoom(room, { type: "player-join", id: player.id, username, pos: player.pos, yaw: player.yaw }, player.id);
      broadcastToRoom(room, { type: "chat", id: null, username: "SERVER", text: `${username} joined.`, ts: Date.now() });
      log(`${username} (${player.id}) joined map "${mapName}" [${room.players.size} in room]`);
      return;
    }

    if (!player) return; // everything below requires having joined

    if (msg.type === "state"){
      const now = Date.now();
      if (now - lastStateAt < STATE_MIN_INTERVAL_MS) return;
      lastStateAt = now;
      if (!Array.isArray(msg.pos) || msg.pos.length !== 3 || !msg.pos.every(Number.isFinite)) return;
      if (!Number.isFinite(msg.yaw) || !Number.isFinite(msg.pitch)) return;
      player.pos = msg.pos; player.yaw = msg.yaw; player.pitch = msg.pitch;
      broadcastToRoom(player.room, { type: "player-state", id: player.id, pos: player.pos, yaw: player.yaw, pitch: player.pitch }, player.id);
      return;
    }

    if (msg.type === "chat"){
      const now = Date.now();
      chatTimes = chatTimes.filter(t => now - t < CHAT_WINDOW_MS);
      if (chatTimes.length >= CHAT_MAX_IN_WINDOW) return; // silently drop -- basic flood control
      chatTimes.push(now);
      if (typeof msg.text !== "string") return;
      // eslint-disable-next-line no-control-regex
      const text = msg.text.replace(/[\x00-\x08\x0b\x0c\x0e-\x1f]/g, "").trim().slice(0, CHAT_MAX_LEN);
      if (!text) return;
      broadcastToRoom(player.room, { type: "chat", id: player.id, username: player.username, text, ts: now });
      return;
    }
  });

  ws.on("close", () => {
    if (!player) return;
    player.room.players.delete(player.id);
    broadcastToRoom(player.room, { type: "player-leave", id: player.id });
    broadcastToRoom(player.room, { type: "chat", id: null, username: "SERVER", text: `${player.username} left.`, ts: Date.now() });
    log(`${player.username} (${player.id}) disconnected`);
  });
  ws.on("error", (err) => { log("socket error: " + err.message); });
}

// ---------------------------------------------------------------------
// admin console (stdin) -- the operator's own terminal, not a network API
// ---------------------------------------------------------------------
function findPlayerByName(name){
  const matches = [];
  for (const room of rooms.values()) {
    for (const p of room.players.values()) {
      if (p.username.toLowerCase() === name.toLowerCase()) matches.push(p);
    }
  }
  return matches;
}

function printHelp(){
  console.log([
    "commands:",
    "  list                    - list all connected players, by map",
    "  maps                     - list map files available in ./maps",
    "  admin <player_name>      - grant that player editor access",
    "  unadmin <player_name>    - revoke editor access",
    "  kick <player_name>       - disconnect that player",
    "  say <message>            - broadcast a SERVER chat message to everyone",
    "  help                     - show this again",
    "  stop / exit               - shut the server down",
  ].join("\n"));
}

function setupConsole(){
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout, prompt: "server> " });
  rl.prompt();
  rl.on("line", (line) => {
    const trimmed = line.trim();
    if (!trimmed){ rl.prompt(); return; }
    const [cmd, ...rest] = trimmed.split(/\s+/);
    const argStr = rest.join(" ");
    switch ((cmd || "").toLowerCase()){
      case "help": printHelp(); break;
      case "maps": console.log(listMapNames().join(", ") || "(none found in " + MAPS_DIR + ")"); break;
      case "list": {
        if (rooms.size === 0){ console.log("no active rooms."); break; }
        for (const room of rooms.values()) {
          console.log(`map "${room.mapName}" (${room.players.size} player(s)):`);
          for (const p of room.players.values()) console.log(`  - ${p.username}${p.isAdmin ? " [admin]" : ""}  (${p.id})`);
        }
        break;
      }
      case "admin": case "unadmin": {
        if (!argStr){ console.log(`usage: ${cmd} <player_name>`); break; }
        const matches = findPlayerByName(argStr);
        if (matches.length === 0){ console.log(`no connected player named "${argStr}".`); break; }
        if (matches.length > 1){ console.log(`ambiguous -- multiple players named "${argStr}" in different rooms: ${matches.map(m => m.room.mapName).join(", ")}`); break; }
        const p = matches[0];
        p.isAdmin = (cmd === "admin");
        send(p.ws, { type: "admin", granted: p.isAdmin });
        broadcastToRoom(p.room, { type: "chat", id: null, username: "SERVER", text: `${p.username} is ${p.isAdmin ? "now" : "no longer"} an admin.`, ts: Date.now() });
        console.log(`${p.username} ${p.isAdmin ? "granted" : "revoked"} editor access.`);
        break;
      }
      case "kick": {
        if (!argStr){ console.log("usage: kick <player_name>"); break; }
        const matches = findPlayerByName(argStr);
        if (matches.length === 0){ console.log(`no connected player named "${argStr}".`); break; }
        for (const p of matches) {
          send(p.ws, { type: "kicked", reason: "removed by server operator" });
          p.ws.close();
        }
        console.log(`kicked ${matches.length} connection(s) named "${argStr}".`);
        break;
      }
      case "say": {
        if (!argStr){ console.log("usage: say <message>"); break; }
        for (const room of rooms.values()) broadcastToRoom(room, { type: "chat", id: null, username: "SERVER", text: argStr.slice(0, CHAT_MAX_LEN), ts: Date.now() });
        break;
      }
      case "stop": case "exit": case "quit":
        console.log("shutting down...");
        rl.close();
        shutdown();
        return;
      default:
        console.log(`unknown command "${cmd}" -- type "help" for a list.`);
    }
    rl.prompt();
  });
}

// ---------------------------------------------------------------------
// heartbeat -- drop dead sockets that stop responding to ping
// ---------------------------------------------------------------------
let heartbeatInterval = null;
function setupHeartbeat(wss){
  heartbeatInterval = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (ws.isAlive === false) { ws.terminate(); return; }
      ws.isAlive = false;
      ws.ping();
    });
  }, HEARTBEAT_MS);
}

// ---------------------------------------------------------------------
// main
// ---------------------------------------------------------------------
let httpsServer = null, wss = null;

function shutdown(){
  if (heartbeatInterval) clearInterval(heartbeatInterval);
  for (const room of rooms.values()) if (room.tickInterval) clearInterval(room.tickInterval);
  if (wss) wss.clients.forEach((ws) => ws.close());
  if (httpsServer) httpsServer.close(() => process.exit(0));
  else process.exit(0);
}
process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

function main(){
  if (!fs.existsSync(CERT_PATH) || !fs.existsSync(KEY_PATH)){
    console.error(
      `missing TLS cert/key.\n` +
      `  expected: ${CERT_PATH}\n` +
      `            ${KEY_PATH}\n` +
      `for local/dev use, generate a self-signed pair with: npm run cert\n` +
      `for a real deployment, point CERT_PATH / KEY_PATH at a real certificate (e.g. from Let's Encrypt).`
    );
    process.exit(1);
  }
  fs.mkdirSync(MAPS_DIR, { recursive: true });

  const tlsOptions = { cert: fs.readFileSync(CERT_PATH), key: fs.readFileSync(KEY_PATH) };
  httpsServer = https.createServer(tlsOptions);
  wss = new WebSocket.Server({ server: httpsServer, maxPayload: MAX_PAYLOAD_BYTES });
  wss.on("connection", handleConnection);
  setupHeartbeat(wss);

  // Preload (and onstart-run) any map that actually declares an onstart
  // script, so those run the moment the SERVER starts, not the moment a
  // player happens to join that map. Maps without onstart scripts stay
  // lazily-loaded on first join, as before.
  for (const name of listMapNames()) {
    const data = loadMapFile(name);
    if (data && Array.isArray(data.scripts) && data.scripts.some(s => s && s.onstart)) {
      createRoom(name, data);
    }
  }

  httpsServer.listen(PORT, () => {
    log(`listening on wss://0.0.0.0:${PORT}`);
    log(`maps dir: ${MAPS_DIR} (${listMapNames().length} map(s) found: ${listMapNames().join(", ") || "none"})`);
    log(`preloaded rooms (onstart scripts): ${[...rooms.keys()].join(", ") || "none"}`);
    printHelp();
  });

  setupConsole();
}

main();
