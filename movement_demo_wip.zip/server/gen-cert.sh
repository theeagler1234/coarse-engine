#!/usr/bin/env bash
# Generates a self-signed TLS cert/key pair for local testing of the wss://
# server (server.js). A self-signed cert is fine for you and friends who
# manually accept the browser warning once, or for connecting over a LAN --
# it is NOT suitable for a public server strangers will connect to; for
# that, use a real certificate (e.g. Let's Encrypt / certbot) and point
# CERT_PATH / KEY_PATH at it instead. See README.md.
set -e
cd "$(dirname "$0")"
DAYS="${1:-825}"
openssl req -x509 -newkey rsa:2048 -nodes \
  -keyout key.pem -out cert.pem -days "$DAYS" \
  -subj "/CN=localhost" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
echo ""
echo "wrote cert.pem and key.pem (valid $DAYS days)."
echo "run the server with: node server.js"
