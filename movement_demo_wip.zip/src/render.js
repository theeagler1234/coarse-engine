// ============================================================
// render.js
// ============================================================
"use strict";

function resize(){
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.floor(window.innerWidth * dpr);
  canvas.height = Math.floor(window.innerHeight * dpr);
  gl.viewport(0,0,canvas.width, canvas.height);
}
window.addEventListener("resize", resize);
resize();

function drawScene(viewProj, camPos){
  gl.useProgram(mainProg);
  gl.uniformMatrix4fv(mainUniform.viewProj, false, viewProj);
  gl.uniform3fv(mainUniform.camPos, camPos);
  gl.uniform3f(mainUniform.fogColor, 0.55, 0.62, 0.68);
  // fog is disabled while the map editor is open -- it makes it hard to see
  // and judge distances/placement accurately while building.
  gl.uniform1f(mainUniform.fogEnabled, editorMode ? 0.0 : 1.0);
  gl.uniform1i(mainUniform.tex, 0);
  gl.activeTexture(gl.TEXTURE0);

  for (const name in glBuffers){
    const b = glBuffers[name];
    gl.bindTexture(gl.TEXTURE_2D, b.texture);

    gl.bindBuffer(gl.ARRAY_BUFFER, b.posBuf);
    gl.enableVertexAttribArray(mainAttrib.pos);
    gl.vertexAttribPointer(mainAttrib.pos, 3, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, b.uvBuf);
    gl.enableVertexAttribArray(mainAttrib.uv);
    gl.vertexAttribPointer(mainAttrib.uv, 2, gl.FLOAT, false, 0, 0);

    gl.bindBuffer(gl.ARRAY_BUFFER, b.shadeBuf);
    gl.enableVertexAttribArray(mainAttrib.shade);
    gl.vertexAttribPointer(mainAttrib.shade, 1, gl.FLOAT, false, 0, 0);

    gl.drawArrays(gl.TRIANGLES, 0, b.count);
  }

  if (showCollision){
    gl.useProgram(lineProg);
    gl.uniformMatrix4fv(lineUniform.viewProj, false, viewProj);
    gl.uniform3f(lineUniform.color, 1.0, 0.35, 0.85);
    gl.bindBuffer(gl.ARRAY_BUFFER, lineBuf);
    gl.enableVertexAttribArray(lineAttrib.pos);
    gl.vertexAttribPointer(lineAttrib.pos, 3, gl.FLOAT, false, 0, 0);
    gl.drawArrays(gl.LINES, 0, lineVertCount);
  }
}

// ---------------------------------------------------------------------
// main loop
// ---------------------------------------------------------------------
