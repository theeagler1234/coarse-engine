// ============================================================
// main.js
// ============================================================
"use strict";

const hFps = document.getElementById("hFps");
const hSpeed = document.getElementById("hSpeed");
const hGround = document.getElementById("hGround");
const hCrouch = document.getElementById("hCrouch");
const hPos = document.getElementById("hPos");

let lastTime = performance.now();
let fpsAccum = 0, fpsFrames = 0, fpsDisplay = 0;

function frame(now){
  requestAnimationFrame(frame);
  let dt = (now - lastTime) / 1000;
  lastTime = now;
  if (dt > 0.05) dt = 0.05; // clamp to avoid spiral of death on tab switch etc.

  fpsAccum += dt; fpsFrames++;
  if (fpsAccum >= 0.5){ fpsDisplay = Math.round(fpsFrames/fpsAccum); fpsAccum = 0; fpsFrames = 0; }

  if (pointerLocked){
    physicsStep(dt);
  }
  if (typeof modsUpdate === "function") modsUpdate(dt);

  const eye = [player.pos[0], player.pos[1], player.pos[2] + playerEye(player)];
  const cy = Math.cos(player.pitch), sy = Math.sin(player.pitch);
  const forward = [Math.cos(player.yaw)*cy, Math.sin(player.yaw)*cy, sy];
  const view = mat4LookDir(eye, forward, [0,0,1]);
  const aspect = canvas.width / canvas.height;
  const proj = mat4Perspective(75 * Math.PI/180, aspect, 4, 6000);
  const viewProj = mat4Multiply(proj, view);

  if (pointerLocked) editorUpdate(eye, forward);

  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
  drawScene(viewProj, eye);
  editorRenderFrame(viewProj);

  hFps.textContent = fpsDisplay;
  hSpeed.textContent = Math.round(Math.hypot(player.vel[0], player.vel[1])) + " u/s";
  hGround.textContent = player.noclip ? "n/a" : (player.onGround ? "yes" : "no");
  hCrouch.textContent = player.crouched ? "yes" : "no";
  hPos.textContent = player.pos.map(v=>Math.round(v)).join(", ");
}
requestAnimationFrame(frame);
