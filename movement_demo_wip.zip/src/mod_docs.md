# mod scripts -- API reference

Mod scripts are plain JavaScript you write inside the in-game editor
("MAP EDITOR" panel -> **mod scripts...**). They get saved *inside your map
JSON* (base64-encoded, in a top-level `"scripts"` array) so a single `.json`
file can carry both the geometry and the logic for something like an
inventory system, an economy, or a whole reskinned minigame.

## How execution works (read this first)

- **Loading a map never runs its scripts.** Opening/loading a `.json` only
  decodes the scripts into the list in the modal. You (or whoever's
  running the map) has to explicitly click **run scripts**. Treat a
  script you didn't write yourself like any other downloaded code: read it
  before you run it.
- Clicking **run scripts** runs every script in the list, top to bottom.
  Clicking it again (e.g. after editing one) re-runs all of them cleanly --
  each script's previous hooks are removed first, so you won't get
  duplicate handlers stacking up.
- **stop scripts** removes every hook every script registered. Scripts
  don't get a "shutdown" callback -- just don't rely on any cleanup logic
  running, and design `API.on("update", ...)` handlers to be safe to
  simply stop being called.
- A script that throws (either at top level, or inside one of its own
  `update`/`keydown`/`keyup` handlers) logs the error to the on-screen mod
  console and to the browser devtools console, and does **not** crash the
  game or any other script.

## Isolation -- why your variables won't clash

Each script runs inside its own private function. A `let`, `const`, `var`,
or top-level `function` you declare is scoped to *your script only* -- it
is physically impossible for two scripts to collide on a variable name,
even if both declare `let gold = 0;` at the top. You never need to prefix
or namespace your own local variables.

The **only** things shared between scripts are whatever you explicitly put
there:
- `API.store` -- automatically namespaced per script (see below), so even
  this is private unless you deliberately go through...
- `API.bus` -- a small pub/sub event bus, the one intentional way for two
  scripts to talk to each other (e.g. an economy script announcing a
  purchase that an inventory script listens for).

This is also why the doc file exists: since the engine won't stop you from
building two mods that are *supposed* to interoperate, write down here (or
in comments in your scripts) which `API.bus` event names and `API.store`
keys you're using for that, so a second script author (or future you)
doesn't guess wrong and pick a conflicting name.

## The `API` object

Every script is called as `function(API, console) { ...your code... }`, so
`API` and `console` (the normal browser console) are the only two things
in scope automatically -- everything else you need comes through `API`.

### `API.on(event, handler)`
Registers a handler. Supported events:
- `"update"` -- `handler(dt)` called once per rendered frame, `dt` in
  seconds. This is where most per-frame mod logic (timers, movement of
  your own props, polling player state) belongs.
- `"keydown"` -- `handler(code)` called on keydown, `code` is a standard
  `KeyboardEvent.code` string (`"KeyE"`, `"Digit1"`, `"Tab"`, etc). Only
  fires while the game has pointer lock (i.e. not while a menu/modal is
  open).
- `"keyup"` -- same, on keyup.

```js
let heldTime = 0;
API.on("update", (dt) => {
  heldTime += dt;
});
API.on("keydown", (code) => {
  if (code === "KeyE") API.log("player pressed E, total time alive: " + heldTime.toFixed(1));
});
```

### `API.player` -- read-only snapshots of player state
- `API.player.pos()` -> `[x,y,z]` (a fresh copy each call -- safe to mutate)
- `API.player.vel()` -> `[x,y,z]`
- `API.player.yaw()` / `API.player.pitch()` -> radians
- `API.player.onGround()` -> bool
- `API.player.crouched()` -> bool
- `API.player.noclip()` -> bool

There's no `API.player.setPos()` etc on purpose in this version -- mods
read state and react to it (spawning props, gating logic, UI, economy),
rather than fighting the physics step for control of the player each
frame. If your mod needs to *move* the player (e.g. a teleporter), the
straightforward way for now is a small custom `update` handler that
directly does `player.pos = [...]` -- `player` is the same global object
the engine uses, so this works, but know that you're bypassing collision
for that one frame when you do it.

### `API.world` -- spawning/removing geometry
Mods can drop new brushes into the level the same way the in-game editor
does -- they're real, collidable, paintable geometry, not decoration.
- `API.world.spawnBox(pos, size, tex)` -> returns an entity id (string).
  `pos`/`size` are `[x,y,z]` arrays. `tex` is a texture name string
  (`"floor"`, `"wall"`, `"hazard"`, `"crate"`, `"dirt"`, `"adobe"`, or any
  further texture you've registered) applied to all six faces; defaults to
  `"crate"` if omitted.
- `API.world.spawnRamp(pos, size, tex, axis)` -> same, but a ramp.
  `axis` is `"x"` (default, rises along X) or `"y"` (rises along Y).
- `API.world.remove(entityId)` -- deletes a previously-spawned (or
  any other) entity by id.
- `API.world.exists(entityId)` -> bool.

```js
// a simple "shop stall" prop, and a pressure-plate-style trigger using it
const stallId = API.world.spawnBox([300, 300, 32], [64, 64, 64], "adobe");
API.on("update", () => {
  const p = API.player.pos();
  const dx = p[0]-300, dy = p[1]-300;
  if (Math.hypot(dx, dy) < 80) API.bus.emit("near-shop", { stallId });
});
```

### `API.store` -- small per-script persistent-for-the-session storage
Automatically namespaced to your script, so `API.store.set("gold", 100)`
in an "economy" script and `API.store.set("gold", 3)` in an "inventory"
script never collide -- they're really writing to two separate buckets
under the hood.
- `API.store.get(key, fallback)`
- `API.store.set(key, value)` -- value should be JSON-serializable
- `API.store.all()` -> a plain object copy of everything you've stored

This is in-memory for the current page session (cleared on reload) -- it's
meant for mod-internal state (cooldowns, counters, flags), not as a save
file. If you need real persistence, save/export your own data through
`API.log`/your own UI, or extend this file's storage backend.

### `API.bus` -- cross-mod events
- `API.bus.emit(eventName, payload)`
- `API.bus.on(eventName, handler)` -- `handler(payload)`

Pick descriptive, collision-resistant event names (e.g. `"economy:gold-changed"`
rather than just `"changed"`) and write them down here if you're building a
set of mods meant to work together.

### `API.log(message)`
Prints to both the browser devtools console and a small on-screen mod
console (bottom-left, appears once anything logs to it). Prefer this over
raw `console.log` for anything you want visible in-game.

## Worked example: a two-script "economy + inventory" pair

**`economy.js`**
```js
API.store.set("gold", API.store.get("gold", 50));

API.on("keydown", (code) => {
  if (code !== "KeyB") return; // "buy" key
  const gold = API.store.get("gold", 0);
  if (gold < 10) { API.log("not enough gold"); return; }
  API.store.set("gold", gold - 10);
  API.bus.emit("economy:purchase", { item: "medkit", cost: 10 });
  API.log("bought a medkit, gold left: " + (gold - 10));
});
```

**`inventory.js`**
```js
let items = [];
API.bus.on("economy:purchase", (payload) => {
  items.push(payload.item);
  API.log("inventory now: " + items.join(", "));
});
```

Neither script's local variables (`gold`, `items`) are visible to the
other -- the only thing crossing the boundary is the `"economy:purchase"`
event, deliberately, through `API.bus`.

## Limits / honesty about what this is

This is a lightweight scripting layer for a single-player test-chamber
project, not a hardened sandbox: a script has the full power of JavaScript
and, through `API`/the global `player` object, real access to game state.
It's suitable for mods you write yourself, or ones from people you trust --
it is **not** safe to run an untrusted stranger's map/script pack without
reading it first, the same way you wouldn't run a random `.exe` or shell
script from someone you don't trust.
