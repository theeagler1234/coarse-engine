// ============================================================
// textures.js
// ============================================================
"use strict";

function makeTexture(drawFn, size){
  size = size || 256;
  const c = document.createElement("canvas");
  c.width = c.height = size;
  const ctx = c.getContext("2d");
  drawFn(ctx, size);
  const tex = gl.createTexture();
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, c);
  gl.generateMipmap(gl.TEXTURE_2D);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR_MIPMAP_LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  return tex;
}

function drawConcrete(ctx, s){
  ctx.fillStyle = "#6d7276";
  ctx.fillRect(0,0,s,s);
  // speckle noise
  for (let i=0;i<1400;i++){
    const x=Math.random()*s, y=Math.random()*s;
    const v = 90+Math.random()*60;
    ctx.fillStyle = `rgba(${v},${v},${v+3},0.10)`;
    ctx.fillRect(x,y,1.5,1.5);
  }
  // panel grid
  ctx.strokeStyle = "rgba(30,32,34,0.55)";
  ctx.lineWidth = 3;
  const divs = 4;
  for (let i=0;i<=divs;i++){
    const p = i*s/divs;
    ctx.beginPath(); ctx.moveTo(p,0); ctx.lineTo(p,s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0,p); ctx.lineTo(s,p); ctx.stroke();
  }
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  ctx.strokeRect(1,1,s-2,s-2);
}

function drawMetalPanel(ctx, s){
  const grad = ctx.createLinearGradient(0,0,0,s);
  grad.addColorStop(0, "#5c6773");
  grad.addColorStop(1, "#48525c");
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,s,s);
  ctx.strokeStyle = "rgba(20,24,28,0.6)";
  ctx.lineWidth = 4;
  const divs = 2;
  for (let i=1;i<divs;i++){
    const p = i*s/divs;
    ctx.beginPath(); ctx.moveTo(p,0); ctx.lineTo(p,s); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(0,p); ctx.lineTo(s,p); ctx.stroke();
  }
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  ctx.strokeRect(2,2,s-4,s-4);
  // rivets at panel corners
  ctx.fillStyle = "rgba(15,17,19,0.7)";
  const pad = s/2*0.12;
  for (let cx=0; cx<2; cx++){
    for (let cy=0; cy<2; cy++){
      const bx = cx*s/2, by = cy*s/2;
      const corners = [[pad,pad],[s/2-pad,pad],[pad,s/2-pad],[s/2-pad,s/2-pad]];
      for (const [ox,oy] of corners){
        ctx.beginPath(); ctx.arc(bx+ox, by+oy, 3, 0, Math.PI*2); ctx.fill();
      }
    }
  }
}

function drawHazard(ctx, s){
  ctx.fillStyle = "#2b2b28";
  ctx.fillRect(0,0,s,s);
  ctx.save();
  ctx.beginPath(); ctx.rect(0,0,s,s); ctx.clip();
  const stripeW = s/8;
  ctx.translate(s/2,s/2); ctx.rotate(Math.PI/4); ctx.translate(-s/2,-s/2);
  for (let x=-s; x<s*2; x+=stripeW*2){
    ctx.fillStyle = "#e8b23a";
    ctx.fillRect(x,-s,stripeW,s*3);
  }
  ctx.restore();
  // grated overlay lines for a bit of grip texture
  ctx.strokeStyle = "rgba(0,0,0,0.35)";
  ctx.lineWidth = 1;
  for (let i=0;i<s;i+=8){
    ctx.beginPath(); ctx.moveTo(0,i); ctx.lineTo(s,i); ctx.stroke();
  }
  ctx.strokeStyle = "rgba(20,20,18,0.9)";
  ctx.lineWidth = 4;
  ctx.strokeRect(2,2,s-4,s-4);
}

function drawCrate(ctx, s){
  ctx.fillStyle = "#7a5a3a";
  ctx.fillRect(0,0,s,s);
  for (let i=0;i<6;i++){
    const y = i*s/6;
    ctx.fillStyle = i%2===0 ? "rgba(0,0,0,0.06)" : "rgba(255,255,255,0.04)";
    ctx.fillRect(0,y,s,s/6);
    ctx.strokeStyle = "rgba(35,22,10,0.5)";
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(s,y); ctx.stroke();
  }
  // corner brackets
  ctx.strokeStyle = "rgba(25,25,25,0.85)";
  ctx.lineWidth = 6;
  ctx.strokeRect(3,3,s-6,s-6);
}

function drawDirt(ctx, s){
  // base gradient -- slightly darker/richer toward the bottom
  const grad = ctx.createLinearGradient(0,0,0,s);
  grad.addColorStop(0, "#7a5a3f");
  grad.addColorStop(1, "#5e4530");
  ctx.fillStyle = grad;
  ctx.fillRect(0,0,s,s);
  // large mottled patches for tonal variation
  for (let i=0;i<26;i++){
    const x=Math.random()*s, y=Math.random()*s, r=14+Math.random()*34;
    const dark = Math.random()<0.5;
    ctx.fillStyle = dark ? "rgba(35,24,14,0.10)" : "rgba(150,120,85,0.10)";
    ctx.beginPath(); ctx.ellipse(x,y,r,r*0.7,Math.random()*Math.PI,0,Math.PI*2); ctx.fill();
  }
  // fine speckle for grain/pebbles
  for (let i=0;i<900;i++){
    const x=Math.random()*s, y=Math.random()*s;
    const v = 40+Math.random()*90;
    ctx.fillStyle = `rgba(${v+40},${v+20},${v},0.35)`;
    ctx.fillRect(x,y,1+Math.random()*1.5,1+Math.random()*1.5);
  }
  // a handful of small pebbles/rocks
  for (let i=0;i<18;i++){
    const x=Math.random()*s, y=Math.random()*s, r=1.5+Math.random()*2.5;
    ctx.fillStyle = "rgba(90,80,70,0.55)";
    ctx.beginPath(); ctx.arc(x,y,r,0,Math.PI*2); ctx.fill();
  }
  // a few hairline cracks
  ctx.strokeStyle = "rgba(30,20,12,0.25)";
  ctx.lineWidth = 1;
  for (let i=0;i<5;i++){
    let x=Math.random()*s, y=Math.random()*s;
    ctx.beginPath(); ctx.moveTo(x,y);
    for (let j=0;j<5;j++){
      x += (Math.random()-0.5)*30; y += (Math.random()-0.5)*30;
      ctx.lineTo(x,y);
    }
    ctx.stroke();
  }
}

function drawAdobe(ctx, s){
  ctx.fillStyle = "#c99a66";
  ctx.fillRect(0,0,s,s);
  // subtle overall mottling so it doesn't look flat
  for (let i=0;i<700;i++){
    const x=Math.random()*s, y=Math.random()*s;
    const v = Math.random()*40-20;
    ctx.fillStyle = v>0 ? `rgba(255,235,200,${Math.abs(v)/200})` : `rgba(90,60,30,${Math.abs(v)/200})`;
    ctx.fillRect(x,y,2,2);
  }
  // hand-formed adobe brick courses, offset like real brickwork
  const rows = 5;
  const rowH = s/rows;
  ctx.strokeStyle = "rgba(70,48,28,0.55)";
  ctx.lineWidth = 3;
  for (let r=0;r<=rows;r++){
    const y = r*rowH;
    ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(s,y); ctx.stroke();
  }
  const brickW = s/3;
  for (let r=0;r<rows;r++){
    const y = r*rowH;
    const offset = (r%2===0) ? 0 : brickW/2;
    for (let x=-brickW; x<s+brickW; x+=brickW){
      ctx.beginPath(); ctx.moveTo(x+offset,y); ctx.lineTo(x+offset,y+rowH); ctx.stroke();
    }
  }
  // straw/texture flecks embedded in the mud, a classic adobe tell
  for (let i=0;i<220;i++){
    const x=Math.random()*s, y=Math.random()*s;
    const len = 3+Math.random()*6;
    const ang = Math.random()*Math.PI;
    ctx.strokeStyle = "rgba(210,180,110,0.5)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(x,y);
    ctx.lineTo(x+Math.cos(ang)*len, y+Math.sin(ang)*len);
    ctx.stroke();
  }
  ctx.strokeStyle = "rgba(255,255,255,0.05)";
  ctx.lineWidth = 1;
  ctx.strokeRect(1,1,s-2,s-2);
}

function drawPlayerMarker(ctx, s){
  ctx.fillStyle = "#2c6e8f";
  ctx.fillRect(0,0,s,s);
  ctx.fillStyle = "rgba(255,255,255,0.12)";
  for (let i=0;i<4;i++){
    ctx.fillRect(0, i*s/4 + s/8 - 4, s, 8);
  }
  ctx.strokeStyle = "rgba(255,255,255,0.35)";
  ctx.lineWidth = 6;
  ctx.strokeRect(3,3,s-6,s-6);
}

const TEX = {}; // name -> {tex, glTexture}
function registerTexture(name, drawFn){ TEX[name] = makeTexture(drawFn, 256); }
registerTexture("floor", drawConcrete);
registerTexture("wall", drawMetalPanel);
registerTexture("hazard", drawHazard);
registerTexture("crate", drawCrate);
registerTexture("dirt", drawDirt);
registerTexture("adobe", drawAdobe);
registerTexture("player", drawPlayerMarker); // used for remote-player avatars in multiplayer, not in the paint palette

// ---------------------------------------------------------------------
// brush geometry builder
// ---------------------------------------------------------------------
