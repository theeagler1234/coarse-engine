// ============================================================
// input.js
// ============================================================
"use strict";

let showCollision = false;
let pointerLocked = false;

document.addEventListener("keydown", (e)=>{
  if (!pointerLocked) return;
  // Chrome deliberately refuses to let a page block reserved shortcuts like
  // Ctrl+W/Ctrl+T no matter what preventDefault() does -- that's a browser
  // security feature, not something fixable from here. preventDefault below
  // still helps in Firefox/Safari, and "c" as an equal alt-bind for crouch
  // means an accidental Ctrl+W (from crouch+forward) is no longer the only
  // way to crouch, which is the actually-fixable part of this.
  if (e.ctrlKey){ e.preventDefault(); e.stopPropagation(); }
  switch(e.code){
    case "KeyW": keys.forward = true; break;
    case "KeyS": keys.back = true; break;
    case "KeyA": keys.left = true; break;
    case "KeyD": keys.right = true; break;
    case "Space": keys.jump = true; jumpQueued = true; e.preventDefault(); break;
    case "ControlLeft": case "ControlRight": case "KeyC": keys.crouch = true; break;
    case "KeyN":
      player.noclip = !player.noclip;
      document.getElementById("hMode").textContent = player.noclip?"noclip":"walk";
      if (!player.noclip && editorMode) toggleEditor(); // leaving noclip always leaves the editor too
      break;
    case "KeyL": showCollision = !showCollision; break;
    case "KeyP": toggleEditor(); e.preventDefault(); break;
    case "KeyV":
      if (editorMode) spawnEntityInFrontOfCamera(e.shiftKey ? "ramp" : "box");
      break;
    case "Delete": case "Backspace":
      if (editorMode && selectedEntity){ removeEntity(selectedEntity); refreshEditorPanel(); }
      break;
    case "KeyG": if (editorMode) toggleGrab(); break;
    case "KeyR": if (editorMode) toggleRotate(); break;
    case "KeyT": if (editorMode) toggleStretch(); break;
    case "Digit1": if (editorMode && stretchActive) setStretchAxis(0); break;
    case "Digit2": if (editorMode && stretchActive) setStretchAxis(1); break;
    case "Digit3": if (editorMode && stretchActive) setStretchAxis(2); break;
    case "Comma": if (editorMode) cyclePaint(-1); break;
    case "Period": if (editorMode) cyclePaint(1); break;
  }
  if (typeof modsKeyDown === "function") modsKeyDown(e.code);
});
document.addEventListener("keyup", (e)=>{
  switch(e.code){
    case "KeyW": keys.forward = false; break;
    case "KeyS": keys.back = false; break;
    case "KeyA": keys.left = false; break;
    case "KeyD": keys.right = false; break;
    case "Space": keys.jump = false; break;
    case "ControlLeft": case "ControlRight": case "KeyC": keys.crouch = false; break;
  }
  if (pointerLocked && typeof modsKeyUp === "function") modsKeyUp(e.code);
});

const startScreen = document.getElementById("startScreen");

function requestLock(){ canvas.requestPointerLock(); }
document.getElementById("playBtn").addEventListener("click", requestLock);
startScreen.addEventListener("click", requestLock);

function releasePointerLockSafely(){
  if (document.pointerLockElement){
    try { document.exitPointerLock(); } catch(err) { /* ignore */ }
  }
}

document.addEventListener("pointerlockchange", ()=>{
  pointerLocked = (document.pointerLockElement === canvas);
  // once the editor has been opened, the editor panel takes over as the
  // "paused" UI instead of the big start card -- clicking the canvas (see
  // the click listener above) re-locks the pointer either way.
  startScreen.style.display = (pointerLocked || editorMode) ? "none" : "flex";
  if (!pointerLocked){
    keys.forward = keys.back = keys.left = keys.right = keys.jump = keys.crouch = false;
  }
});
document.addEventListener("pointerlockerror", ()=>{
  pointerLocked = false;
  startScreen.style.display = "flex";
});

// Defensively release the pointer lock (and therefore un-hide the cursor)
// any time the tab/window is about to go away or lose focus, rather than
// relying solely on the browser to fire pointerlockchange on its own. Some
// browser/OS combinations can otherwise leave the cursor hidden system-wide
// after the tab closes.
document.addEventListener("visibilitychange", ()=>{ if (document.hidden) releasePointerLockSafely(); });
window.addEventListener("blur", releasePointerLockSafely);
window.addEventListener("pagehide", releasePointerLockSafely);
window.addEventListener("beforeunload", releasePointerLockSafely);

document.addEventListener("mousemove", (e)=>{
  if (!pointerLocked) return;
  // in rotate mode the mouse spins the selected entity instead of the
  // camera -- see editor.js: accumulateRotateDelta()/editorUpdate().
  if (editorMode && rotateActive && selectedEntity){
    accumulateRotateDelta(e.movementX, e.movementY, e.ctrlKey);
    return;
  }
  player.yaw -= e.movementX * mouseSens * 0.0022;
  player.pitch -= e.movementY * mouseSens * 0.0022;
  const lim = Math.PI/2 - 0.01;
  if (player.pitch > lim) player.pitch = lim;
  if (player.pitch < -lim) player.pitch = -lim;
});

// left-click select/paint, and scroll-wheel grab-distance/stretch --
// both are no-ops outside editor mode (handleEditorClick/Wheel return
// false immediately when !editorMode).
canvas.addEventListener("mousedown", (e)=>{
  if (!pointerLocked || e.button !== 0) return;
  handleEditorClick(e);
});
canvas.addEventListener("wheel", (e)=>{
  if (!pointerLocked) return;
  if (handleEditorWheel(e)) e.preventDefault();
}, { passive:false });

// clicking the canvas re-acquires pointer lock even when the start screen
// itself is hidden (which it is once the editor has been opened once --
// see editor.js: toggleEditor()).
canvas.addEventListener("click", ()=>{ if (!pointerLocked) requestLock(); });

// settings wiring
const sensSlider = document.getElementById("sensSlider");
const sensVal = document.getElementById("sensVal");
sensSlider.addEventListener("input", ()=>{ mouseSens = parseFloat(sensSlider.value); sensVal.textContent = mouseSens.toFixed(2); });
mouseSens = parseFloat(sensSlider.value);

const airSlider = document.getElementById("airSlider");
const airVal = document.getElementById("airVal");
airSlider.addEventListener("input", ()=>{ airAccelerate = parseFloat(airSlider.value); airVal.textContent = airAccelerate.toFixed(0); });
airAccelerate = parseFloat(airSlider.value);

const autoBhopBox = document.getElementById("autoBhop");
autoBhopBox.addEventListener("change", ()=>{ autoBhop = autoBhopBox.checked; });

// re-trigger jump each tick while held, if autobhop is enabled (handled by not clearing keys.jump on keyup logic; simplest: override in physics loop)

// ---------------------------------------------------------------------
// render
// ---------------------------------------------------------------------
