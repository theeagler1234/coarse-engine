// ============================================================
// editor.js -- in-game map editor
// ============================================================
// Entry point: press N (noclip) then P (editor) -- see input.js for the
// actual key bindings, this file just implements what they do.
//
// Data model: an "entity" is a user-placed box or ramp brush, kept in
// `editorEntities` as plain data (pos/size/rot/faceTex) so it round-trips
// cleanly to/from JSON. Each entity also has its *current* built brush
// cached at `ent._brush` (not serialized) which lives inside the same
// global `brushes` array collision.js and geometry_upload.js already
// iterate -- so once an entity brush is pushed in, it collides and renders
// for free, no changes needed to either of those files.
"use strict";

const editorEntities = [];
let editorMode = false;
let selectedEntity = null;
let hoveredHit = null;

let grabActive = false, grabDistance = 200;
let rotateActive = false;
let stretchActive = false, stretchAxis = 0; // 0=x, 1=y, 2=z
let currentPaintIndex = 0;

let lastEye = [0, 0, 0], lastForward = [1, 0, 0];
let pendingRotateDX = 0, pendingRotateDY = 0, pendingRotateCtrl = false;

let entityIdCounter = 0;
function genEntityId(){ return "ent_" + (++entityIdCounter) + "_" + Math.random().toString(36).slice(2, 7); }

// UTF-8 safe base64 helpers, shared with mods.js (script save/load) --
// plain btoa/atob choke on any non-Latin1 character (emoji, accents, etc.
// in a script's comments or strings), so route through encodeURIComponent
// first the way MDN recommends.
function utf8ToBase64(str){ return btoa(unescape(encodeURIComponent(str))); }
function base64ToUtf8(b64){ return decodeURIComponent(escape(atob(b64))); }

// ---------------------------------------------------------------------
// entity <-> brush
// ---------------------------------------------------------------------

function defaultFaceTex(type, texName){
  return (type === "ramp" || type === "rampy")
    ? { bottom: texName, slope: texName, backwall: texName, sideA: texName, sideB: texName }
    : { top: texName, bottom: texName, north: texName, south: texName, east: texName, west: texName };
}

// Expands a texture spec that may be a single string (uniform across every
// face) into the full per-slot object faceTex needs -- so that every entity,
// including ones wrapped from the base map (see wrapBaseBrush() below), has
// a real per-face object it's safe to mutate face-by-face when painting.
// Passing a string straight into an entity's faceTex would break Alt+click
// painting (`ent.faceTex[slot] = tex`) since strings are immutable.
function expandFaceTex(type, tex){
  if (tex && typeof tex === "object") return JSON.parse(JSON.stringify(tex));
  return defaultFaceTex(type, tex);
}

function xformPoint(local, ent){
  const r = rotateEuler(local, ent.rot);
  return [r[0] + ent.pos[0], r[1] + ent.pos[1], r[2] + ent.pos[2]];
}
function xformNormal(n, ent){ return rotateEuler(n, ent.rot); }

// Rebuilds a brush from scratch for the entity's current pos/size/rot/
// faceTex. Called after every edit -- cheap enough at this map's scale.
function buildEntityBrush(ent){
  const hx = ent.size[0] / 2, hy = ent.size[1] / 2, hz = ent.size[2] / 2;
  const local = (ent.type === "ramp")
    ? makeRampX(-hx, hx, -hy, hy, -hz, hz, ent.faceTex)
    : (ent.type === "rampy")
    ? makeRampY(-hx, hx, -hy, hy, -hz, hz, ent.faceTex)
    : makeBoxBrush([-hx, -hy, -hz], [hx, hy, hz], ent.faceTex);
  const faces = local.faces.map(f => ({
    verts: f.verts.map(v => xformPoint(v, ent)),
    normal: xformNormal(f.normal, ent),
    tex: f.tex,
    slot: f.slot,
  }));
  const planes = faces.map(planeFromFace);
  let min = [Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity];
  for (const f of faces){
    for (const v of f.verts){
      for (let i = 0; i < 3; i++){
        if (v[i] < min[i]) min[i] = v[i];
        if (v[i] > max[i]) max[i] = v[i];
      }
    }
  }
  return { faces, planes, min, max, entity: ent };
}

function createEntity(spec){
  const ent = {
    id: spec.id || genEntityId(),
    type: (spec.type === "ramp" || spec.type === "rampy") ? spec.type : "box",
    pos: spec.pos.slice(),
    size: spec.size.slice(),
    rot: (spec.rot || [0, 0, 0]).slice(),
    faceTex: JSON.parse(JSON.stringify(spec.faceTex)),
    isBase: !!spec.isBase,
  };
  const brush = buildEntityBrush(ent);
  ent._brush = brush;
  brushes.push(brush);
  editorEntities.push(ent);
  rebuildGeometry();
  return ent;
}

function updateEntity(ent){
  const idx = brushes.indexOf(ent._brush);
  const newBrush = buildEntityBrush(ent);
  if (idx >= 0) brushes[idx] = newBrush; else brushes.push(newBrush);
  ent._brush = newBrush;
  rebuildGeometry();
}

function removeEntity(ent){
  const idx = brushes.indexOf(ent._brush);
  if (idx >= 0) brushes.splice(idx, 1);
  const eIdx = editorEntities.indexOf(ent);
  if (eIdx >= 0) editorEntities.splice(eIdx, 1);
  if (selectedEntity === ent) selectedEntity = null;
  rebuildGeometry();
}

function clearAllEntities(){
  for (const ent of editorEntities.slice()) removeEntity(ent);
}

// ---------------------------------------------------------------------
// base map -> editable entities
// ---------------------------------------------------------------------
// map.js builds the starting test chamber (ground, walls, staircase, ramps,
// crates, platforms) the exact same way it always has -- via addBox/addRampX/
// addRampY -- so that geometry is pixel-for-pixel identical to before. It
// can't wrap those pieces into full editor entities itself, though, because
// map.js runs (and needs `brushes` populated) before this file has loaded.
// Instead map.js stashes one spec per piece into `baseBrushSpecs`, and this
// runs once editor.js is loaded to attach a real, editable `.entity` to each
// already-built brush -- no rebuild, no geometry drift, just metadata.
// Once wrapped, base pieces are ordinary entities: selectable, movable,
// rotatable, resizable, paintable, and deletable exactly like anything you
// place yourself (`ent.isBase` just flags where it came from, for the UI and
// for "reset base map").
function wrapBaseBrush(spec){
  const min = spec.min, max = spec.max;
  const size = [max[0] - min[0], max[1] - min[1], max[2] - min[2]];
  const pos = [(min[0] + max[0]) / 2, (min[1] + max[1]) / 2, (min[2] + max[2]) / 2];
  const ent = {
    id: genEntityId(),
    type: spec.type,
    pos, size, rot: [0, 0, 0],
    faceTex: expandFaceTex(spec.type, spec.tex),
    isBase: true,
  };
  ent._brush = spec.brush;
  spec.brush.entity = ent;
  editorEntities.push(ent);
  return ent;
}

let defaultMapSnapshot = null;
function initBaseEntities(){
  for (const spec of (typeof baseBrushSpecs !== "undefined" ? baseBrushSpecs : [])) wrapBaseBrush(spec);
  // snapshot the full starting map (base chamber + nothing else yet) so
  // "reset base map" can restore it even after base pieces are edited/deleted.
  defaultMapSnapshot = serializeMap();
}
function resetBaseMap(){
  if (!defaultMapSnapshot) return;
  loadMapFromObject(defaultMapSnapshot);
}

function spawnEntityInFrontOfCamera(type){
  const texName = EDITOR_PALETTE[currentPaintIndex];
  const pos = [
    lastEye[0] + lastForward[0] * EDITOR_SPAWN_DIST,
    lastEye[1] + lastForward[1] * EDITOR_SPAWN_DIST,
    lastEye[2] + lastForward[2] * EDITOR_SPAWN_DIST,
  ];
  const size = [EDITOR_DEFAULT_SIZE, EDITOR_DEFAULT_SIZE, EDITOR_DEFAULT_SIZE];
  const ent = createEntity({ type, pos, size, rot: [0, 0, 0], faceTex: defaultFaceTex(type, texName) });
  selectedEntity = ent;
  grabActive = rotateActive = stretchActive = false;
  refreshEditorPanel();
  return ent;
}

// ---------------------------------------------------------------------
// picking -- exact ray vs convex brush, using the brush's own half-space
// planes (works for rotated entity brushes with no extra bookkeeping,
// and tells us exactly which face -- and thus which paintable slot -- was
// hit).
// ---------------------------------------------------------------------

function raycastBrush(brush, o, d, maxT){
  let tmin = 0, tmax = maxT, hitFace = null;
  for (const p of brush.planes){
    const denom = V.dot(p.n, d);
    const distToPlane = p.d - V.dot(p.n, o);
    if (Math.abs(denom) < 1e-9){
      if (distToPlane < 0) return null; // parallel to this plane and outside it
      continue;
    }
    const t = distToPlane / denom;
    if (denom < 0){ if (t > tmin){ tmin = t; hitFace = p.face; } }
    else { if (t < tmax) tmax = t; }
    if (tmin > tmax) return null;
  }
  if (!hitFace) return null; // ray started inside the brush -- not a valid pick
  return {
    t: tmin, brush, face: hitFace, normal: hitFace.normal,
    point: [o[0] + d[0] * tmin, o[1] + d[1] * tmin, o[2] + d[2] * tmin],
  };
}

function raycastScene(o, d, maxT){
  let best = null;
  for (const brush of brushes){
    const hit = raycastBrush(brush, o, d, best ? best.t : maxT);
    if (hit && (!best || hit.t < best.t)) best = hit;
  }
  return best;
}

// ---------------------------------------------------------------------
// mode toggles (bound to keys in input.js)
// ---------------------------------------------------------------------

function toggleEditor(){
  editorMode = !editorMode;
  if (editorMode){
    player.noclip = true;
    const hMode = document.getElementById("hMode");
    if (hMode) hMode.textContent = "noclip";
  } else {
    grabActive = rotateActive = stretchActive = false;
    selectedEntity = null;
    hoveredHit = null;
  }
  const panel = document.getElementById("editorPanel");
  if (panel) panel.style.display = editorMode ? "block" : "none";
  const startScreen = document.getElementById("startScreen");
  if (startScreen && pointerLocked) startScreen.style.display = "none";
  refreshEditorPanel();
}

function toggleGrab(){
  if (!selectedEntity) return;
  grabActive = !grabActive;
  if (grabActive){
    rotateActive = false; stretchActive = false;
    grabDistance = V.length(V.sub(selectedEntity.pos, lastEye));
    grabDistance = Math.max(EDITOR_GRAB_MIN, Math.min(EDITOR_GRAB_MAX, grabDistance));
  }
  refreshEditorPanel();
}
function toggleRotate(){
  if (!selectedEntity) return;
  rotateActive = !rotateActive;
  if (rotateActive){ grabActive = false; stretchActive = false; }
  refreshEditorPanel();
}
function toggleStretch(){
  if (!selectedEntity) return;
  stretchActive = !stretchActive;
  if (stretchActive){ grabActive = false; rotateActive = false; }
  refreshEditorPanel();
}
function setStretchAxis(i){ stretchAxis = i; refreshEditorPanel(); }
function cyclePaint(dir){
  const n = EDITOR_PALETTE.length;
  currentPaintIndex = (currentPaintIndex + dir + n) % n;
  refreshEditorPanel();
}

function accumulateRotateDelta(dx, dy, ctrlHeld){
  pendingRotateDX += dx;
  pendingRotateDY += dy;
  pendingRotateCtrl = ctrlHeld;
}

// mousedown (left button) while pointer-locked and in editor mode
function handleEditorClick(e){
  if (!editorMode) return false;
  if (e.altKey){
    if (hoveredHit){
      const tex = EDITOR_PALETTE[currentPaintIndex];
      const b = hoveredHit.brush, f = hoveredHit.face;
      if (b.entity){ b.entity.faceTex[f.slot] = tex; updateEntity(b.entity); }
      else { f.tex = tex; rebuildGeometry(); }
    }
    return true;
  }
  if (grabActive){ grabActive = false; refreshEditorPanel(); return true; }
  if (rotateActive){ rotateActive = false; refreshEditorPanel(); return true; }
  selectedEntity = (hoveredHit && hoveredHit.brush.entity) ? hoveredHit.brush.entity : null;
  refreshEditorPanel();
  return true;
}

function handleEditorWheel(e){
  if (!editorMode) return false;
  if (grabActive){
    grabDistance += (e.deltaY < 0 ? 1 : -1) * EDITOR_GRAB_WHEEL;
    grabDistance = Math.max(EDITOR_GRAB_MIN, Math.min(EDITOR_GRAB_MAX, grabDistance));
    return true;
  }
  if (stretchActive && selectedEntity){
    const delta = (e.deltaY < 0 ? 1 : -1) * EDITOR_STRETCH_WHEEL;
    selectedEntity.size[stretchAxis] = Math.max(EDITOR_STRETCH_MIN, selectedEntity.size[stretchAxis] + delta);
    updateEntity(selectedEntity);
    refreshEditorPanel();
    return true;
  }
  return false;
}

// ---------------------------------------------------------------------
// per-frame update, called from main.js
// ---------------------------------------------------------------------

function editorUpdate(eye, forward){
  lastEye = eye; lastForward = forward;
  if (!editorMode){ hoveredHit = null; return; }

  hoveredHit = raycastScene(eye, forward, EDITOR_RAY_DIST);

  if (rotateActive && selectedEntity && (pendingRotateDX !== 0 || pendingRotateDY !== 0)){
    selectedEntity.rot[2] += pendingRotateDX * EDITOR_ROTATE_SENS; // yaw
    if (pendingRotateCtrl) selectedEntity.rot[0] += pendingRotateDY * EDITOR_ROTATE_SENS; // roll
    else selectedEntity.rot[1] += pendingRotateDY * EDITOR_ROTATE_SENS; // pitch
    pendingRotateDX = 0; pendingRotateDY = 0;
    updateEntity(selectedEntity);
  }

  if (grabActive && selectedEntity){
    selectedEntity.pos = [
      eye[0] + forward[0] * grabDistance,
      eye[1] + forward[1] * grabDistance,
      eye[2] + forward[2] * grabDistance,
    ];
    updateEntity(selectedEntity);
  }

  refreshEditorPanel();
}

// ---------------------------------------------------------------------
// overlay rendering -- reuses the plain-color line shader from
// webgl_setup.js, same one the B/L collision-debug view uses.
// ---------------------------------------------------------------------

const editorHighlightBuf = gl.createBuffer();
function edgesForBrush(brush){
  const segs = [];
  for (const f of brush.faces){
    const verts = f.verts;
    for (let i = 0; i < verts.length; i++){
      const a = verts[i], b = verts[(i + 1) % verts.length];
      segs.push(a[0], a[1], a[2], b[0], b[1], b[2]);
    }
  }
  return segs;
}

function editorRenderFrame(viewProj){
  if (!editorMode) return;
  gl.useProgram(lineProg);
  gl.uniformMatrix4fv(lineUniform.viewProj, false, viewProj);
  gl.bindBuffer(gl.ARRAY_BUFFER, editorHighlightBuf);
  gl.enableVertexAttribArray(lineAttrib.pos);
  gl.vertexAttribPointer(lineAttrib.pos, 3, gl.FLOAT, false, 0, 0);
  gl.disable(gl.DEPTH_TEST);

  if (hoveredHit && !(selectedEntity && hoveredHit.brush === selectedEntity._brush)){
    const segs = edgesForBrush(hoveredHit.brush);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(segs), gl.DYNAMIC_DRAW);
    gl.uniform3f(lineUniform.color, 0.4, 0.85, 1.0);
    gl.drawArrays(gl.LINES, 0, segs.length / 3);
  }
  if (selectedEntity && selectedEntity._brush){
    const segs = edgesForBrush(selectedEntity._brush);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(segs), gl.DYNAMIC_DRAW);
    gl.uniform3f(lineUniform.color, 1.0, 0.55, 0.1);
    gl.drawArrays(gl.LINES, 0, segs.length / 3);
  }
  gl.enable(gl.DEPTH_TEST);
}

// ---------------------------------------------------------------------
// save / load
// ---------------------------------------------------------------------

function serializeMap(){
  return {
    version: 2,
    entities: editorEntities.map(e => ({
      id: e.id, type: e.type, pos: e.pos, size: e.size, rot: e.rot, faceTex: e.faceTex, isBase: !!e.isBase,
    })),
    scripts: (typeof editorScripts !== "undefined" ? editorScripts : []).map(s => ({
      id: s.id, name: s.name, code_b64: utf8ToBase64(s.code),
    })),
  };
}

function downloadMapJSON(){
  const data = JSON.stringify(serializeMap(), null, 2);
  const blob = new Blob([data], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const stamp = new Date().toISOString().replace(/[:.]/g, "-");
  a.href = url;
  a.download = `movement-editor-build-${stamp}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function loadMapFromObject(data){
  if (!data || !Array.isArray(data.entities)){
    alert("that doesn't look like a saved build (missing an \"entities\" array)");
    return;
  }
  clearAllEntities();
  for (const spec of data.entities){
    if (!spec || (spec.type !== "box" && spec.type !== "ramp" && spec.type !== "rampy")) continue;
    if (!Array.isArray(spec.pos) || !Array.isArray(spec.size)) continue;
    createEntity({
      id: spec.id,
      type: spec.type,
      pos: spec.pos,
      size: spec.size,
      rot: Array.isArray(spec.rot) ? spec.rot : [0, 0, 0],
      faceTex: spec.faceTex || defaultFaceTex(spec.type, EDITOR_PALETTE[0]),
      isBase: !!spec.isBase,
    });
  }
  if (typeof loadScriptsFromSave === "function") loadScriptsFromSave(Array.isArray(data.scripts) ? data.scripts : []);
  selectedEntity = null;
  refreshEditorPanel();
}

function loadMapFromFile(file){
  const reader = new FileReader();
  reader.onload = () => {
    try { loadMapFromObject(JSON.parse(reader.result)); }
    catch (err){ alert("couldn't parse that file as JSON: " + err.message); }
  };
  reader.readAsText(file);
}

// ---------------------------------------------------------------------
// UI panel
// ---------------------------------------------------------------------

function fmt3(a){ return a.map(v => Math.round(v * 10) / 10).join(", "); }

function refreshEditorPanel(){
  const modeBadge = document.getElementById("epModeBadge");
  if (!modeBadge) return; // panel markup not present
  modeBadge.textContent = grabActive ? "GRAB"
    : rotateActive ? "ROTATE"
    : stretchActive ? `STRETCH (${"XYZ"[stretchAxis]})`
    : "SELECT";

  const selEl = document.getElementById("epSel");
  const posEl = document.getElementById("epPos");
  const sizeEl = document.getElementById("epSize");
  const rotEl = document.getElementById("epRot");
  if (selectedEntity){
    const tag = selectedEntity.isBase ? " (base)" : "";
    selEl.textContent = `${selectedEntity.type}${tag} \u00b7 ${selectedEntity.id.slice(0, 10)}`;
    posEl.textContent = fmt3(selectedEntity.pos);
    sizeEl.textContent = fmt3(selectedEntity.size);
    rotEl.textContent = fmt3(selectedEntity.rot) + " deg";
  } else {
    const hov = hoveredHit && hoveredHit.brush.entity;
    selEl.textContent = hov ? `(hover) ${hov.type}${hov.isBase ? " (base)" : ""}` : "none";
    posEl.textContent = sizeEl.textContent = rotEl.textContent = "--";
  }

  const paintEl = document.getElementById("epPaint");
  if (paintEl) paintEl.textContent = EDITOR_PALETTE[currentPaintIndex];
  const countEl = document.getElementById("epCount");
  if (countEl) countEl.textContent = String(editorEntities.filter(e => !e.isBase).length);
  const baseCountEl = document.getElementById("epBaseCount");
  if (baseCountEl) baseCountEl.textContent = String(editorEntities.filter(e => e.isBase).length);
}

function initEditorUI(){
  const panel = document.getElementById("editorPanel");
  if (!panel) return;
  document.getElementById("epSpawnBox").addEventListener("click", () => { if (editorMode) spawnEntityInFrontOfCamera("box"); });
  document.getElementById("epSpawnRamp").addEventListener("click", () => { if (editorMode) spawnEntityInFrontOfCamera("ramp"); });
  document.getElementById("epDelete").addEventListener("click", () => { if (editorMode && selectedEntity) removeEntity(selectedEntity); refreshEditorPanel(); });
  document.getElementById("epSave").addEventListener("click", downloadMapJSON);
  const loadInput = document.getElementById("epLoadInput");
  document.getElementById("epLoadBtn").addEventListener("click", () => loadInput.click());
  loadInput.addEventListener("change", () => {
    if (loadInput.files && loadInput.files[0]) loadMapFromFile(loadInput.files[0]);
    loadInput.value = "";
  });
  document.getElementById("epClear").addEventListener("click", () => {
    if (confirm("delete ALL brushes, including the base test chamber? (use \"reset base map\" afterward if you want the chamber back)")){
      clearAllEntities();
      refreshEditorPanel();
    }
  });
  const resetBtn = document.getElementById("epResetBase");
  if (resetBtn) resetBtn.addEventListener("click", () => {
    if (confirm("reset to the original base test chamber? this replaces EVERYTHING currently in the map, including anything you've placed.")){
      resetBaseMap();
    }
  });
  refreshEditorPanel();
}
initEditorUI();
initBaseEntities();

// ---------------------------------------------------------------------
// input
// ---------------------------------------------------------------------
