// ============================================================
// player.js
// ============================================================
"use strict";

const player = {
  pos: [0, 0, 80],
  vel: [0, 0, 0],
  yaw: 0,
  pitch: 0,
  onGround: false,
  noclip: false,
  crouched: false,
};

function playerHalf(p){ return [HALF_XY, HALF_XY, p.crouched ? CROUCH_HALF_Z : STAND_HALF_Z]; }
function playerEye(p){ return p.crouched ? CROUCH_EYE : STAND_EYE; }

const keys = { forward:false, back:false, left:false, right:false, jump:false, crouch:false };
let autoBhop = false;
let jumpQueued = false; // edge-triggered jump request (consumed on landing) when auto-bhop is off
let mouseSens = 0.22;

function applyFriction(vel, dt){
  const speed = Math.hypot(vel[0], vel[1]);
  if (speed < 1e-4) return;
  const control = speed < STOP_SPEED ? STOP_SPEED : speed;
  let drop = control * FRICTION * dt;
  let newSpeed = speed - drop;
  if (newSpeed < 0) newSpeed = 0;
  const scale = newSpeed / speed;
  vel[0] *= scale; vel[1] *= scale;
}
function accelerate(vel, wishDir, wishSpeed, accel, dt){
  const currentSpeed = vel[0]*wishDir[0] + vel[1]*wishDir[1];
  const addSpeed = wishSpeed - currentSpeed;
  if (addSpeed <= 0) return;
  let accelSpeed = accel * dt * wishSpeed;
  if (accelSpeed > addSpeed) accelSpeed = addSpeed;
  vel[0] += accelSpeed * wishDir[0];
  vel[1] += accelSpeed * wishDir[1];
}

function computeWishDir(maxSpeed){
  const fx = Math.cos(player.yaw), fy = Math.sin(player.yaw);
  const rx = Math.cos(player.yaw - Math.PI/2), ry = Math.sin(player.yaw - Math.PI/2);
  let fmove = 0, smove = 0;
  if (keys.forward) fmove += 1;
  if (keys.back) fmove -= 1;
  if (keys.right) smove += 1;
  if (keys.left) smove -= 1;
  let wx = fx*fmove + rx*smove, wy = fy*fmove + ry*smove;
  const len = Math.hypot(wx, wy);
  if (len < 1e-4) return { dir:[0,0], speed:0 };
  return { dir:[wx/len, wy/len], speed: maxSpeed };
}

function updateCrouch(){
  const wantCrouch = keys.crouch;
  if (wantCrouch && !player.crouched){
    // crouching down is always allowed; keep feet planted, drop the center.
    player.pos[2] -= (STAND_HALF_Z - CROUCH_HALF_Z);
    player.crouched = true;
  } else if (!wantCrouch && player.crouched){
    // only stand back up if there's room -- test at the standing height/position first.
    const testPos = player.pos.slice();
    testPos[2] += (STAND_HALF_Z - CROUCH_HALF_Z);
    if (canFit(testPos, [HALF_XY, HALF_XY, STAND_HALF_Z])){
      player.pos[2] = testPos[2];
      player.crouched = false;
    }
    // else: stays crouched, will retry next frame automatically
  }
}

function physicsStep(dt){
  if (player.noclip){
    const cy = Math.cos(player.pitch), sy = Math.sin(player.pitch);
    const fwd = [Math.cos(player.yaw)*cy, Math.sin(player.yaw)*cy, sy];
    const right = [Math.cos(player.yaw - Math.PI/2), Math.sin(player.yaw - Math.PI/2), 0];
    let fmove=0, smove=0, umove=0;
    if (keys.forward) fmove+=1; if (keys.back) fmove-=1;
    if (keys.right) smove+=1; if (keys.left) smove-=1;
    if (keys.jump) umove+=1;
    if (keys.crouch) umove-=1;
    const vx = fwd[0]*fmove + right[0]*smove;
    const vy = fwd[1]*fmove + right[1]*smove;
    const vz = fwd[2]*fmove + umove;
    const l = Math.hypot(vx,vy,vz);
    if (l > 1e-4){
      player.pos[0] += (vx/l) * NOCLIP_SPEED * dt;
      player.pos[1] += (vy/l) * NOCLIP_SPEED * dt;
      player.pos[2] += (vz/l) * NOCLIP_SPEED * dt;
    }
    player.vel = [0,0,0];
    player.onGround = false;
    return;
  }

  updateCrouch();
  const half = playerHalf(player);

  const wasOnGround = probeGround(player.pos, half);
  player.vel[2] -= GRAVITY * dt;

  const maxSpeed = player.crouched ? CROUCH_SPEED : MAX_SPEED;
  const wish = computeWishDir(maxSpeed);
  if (wasOnGround) applyFriction(player.vel, dt);
  const accel = wasOnGround ? ACCELERATE : airAccelerate;
  accelerate(player.vel, wish.dir, wish.speed, accel, dt);

  const wantJump = autoBhop ? keys.jump : jumpQueued;
  if (wasOnGround && wantJump){
    player.vel[2] = JUMP_SPEED;
    jumpQueued = false;
  }

  const startPos = player.pos.slice();
  const plain = moveIntegrate(player.pos, player.vel, dt, half, 4);
  let finalPos = plain.pos, finalVel = plain.vel;

  // only attempt the stair-step assist if we were grounded and aren't actively
  // launching upward (e.g. mid-jump) this frame.
  if (wasOnGround && player.vel[2] <= 0){
    const stepped = tryStepUp(startPos, player.vel, dt, half);
    if (stepped.ok){
      const distPlain = Math.hypot(plain.pos[0]-startPos[0], plain.pos[1]-startPos[1]);
      const distStep = Math.hypot(stepped.pos[0]-startPos[0], stepped.pos[1]-startPos[1]);
      if (distStep > distPlain + 0.01){
        finalPos = stepped.pos; finalVel = stepped.vel;
      }
    }
  }

  player.pos = finalPos;
  player.vel = finalVel;
  player.onGround = probeGround(player.pos, half);
}

// ---------------------------------------------------------------------
// input
// ---------------------------------------------------------------------
