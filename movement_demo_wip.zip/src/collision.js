// ============================================================
// collision.js
// ============================================================
"use strict";

function resolveOne(pos, half, brush){
  let bestDepth = Infinity, bestNormal = null;
  for (const p of brush.planes){
    const centerProj = pos[0]*p.n[0] + pos[1]*p.n[1] + pos[2]*p.n[2];
    const extentProj = Math.abs(p.n[0])*half[0] + Math.abs(p.n[1])*half[1] + Math.abs(p.n[2])*half[2];
    const minProj = centerProj - extentProj;
    const depth = p.d - minProj;
    if (depth <= 0) return null; // fully separated by this plane -> no overlap with brush
    if (depth < bestDepth){ bestDepth = depth; bestNormal = p.n; }
  }
  return { normal: bestNormal, depth: bestDepth };
}

// push-out + velocity-clip only. does NOT decide "on ground" -- see probeGround below.
function resolveCollisions(pos, vel, half){
  for (let iter=0; iter<4; iter++){
    let any = false;
    for (const brush of brushes){
      const hit = resolveOne(pos, half, brush);
      if (!hit) continue;
      any = true;
      pos[0] += hit.normal[0]*hit.depth;
      pos[1] += hit.normal[1]*hit.depth;
      pos[2] += hit.normal[2]*hit.depth;
      const vn = vel[0]*hit.normal[0] + vel[1]*hit.normal[1] + vel[2]*hit.normal[2];
      if (vn < 0){
        vel[0] -= hit.normal[0]*vn;
        vel[1] -= hit.normal[1]*vn;
        vel[2] -= hit.normal[2]*vn;
      }
    }
    if (!any) break;
  }
}

// "am I standing on something" check, decoupled from whether the solver had to
// push anything out THIS exact substep. A resting player sits at exactly zero
// penetration (by design of the push-out solver above), so testing at the
// player's *actual* position is unreliable -- it flickers between "touching"
// and "not touching" from one substep to the next. Probing a couple of units
// below the player instead gives a stable, non-flickering ground signal.
function probeGround(pos, half){
  const t = pos.slice();
  t[2] -= GROUND_PROBE;
  for (const brush of brushes){
    const hit = resolveOne(t, half, brush);
    if (hit && hit.normal[2] > 0.7) return true;
  }
  return false;
}

// true if an AABB at pos/half doesn't overlap any brush at all (used for the
// uncrouch "is there room to stand up" check)
function canFit(pos, half){
  for (const brush of brushes){
    if (resolveOne(pos, half, brush)) return false;
  }
  return true;
}

function moveIntegrate(pos, vel, dt, half, subSteps){
  let p = pos.slice(), v = vel.slice();
  const subDt = dt / subSteps;
  for (let i=0;i<subSteps;i++){
    p[0] += v[0]*subDt; p[1] += v[1]*subDt; p[2] += v[2]*subDt;
    resolveCollisions(p, v, half);
  }
  return { pos:p, vel:v };
}

// stair-step assist: try stepping up, moving horizontally, then tracing back
// down onto the new surface. run once per full frame (not per substep).
function tryStepUp(startPos, vel, dt, half){
  let p = startPos.slice();
  p[2] += STEP_HEIGHT;
  let v = vel.slice();
  resolveCollisions(p, v, half); // clear any embedding right after raising
  p[0] += vel[0]*dt;
  p[1] += vel[1]*dt;
  resolveCollisions(p, v, half);
  const steps = 24;
  for (let s=0; s<steps; s++){
    p[2] -= STEP_HEIGHT/steps;
    if (probeGround(p, half)){ v[2] = 0; return { pos:p, vel:v, ok:true }; }
    if (p[2] < startPos[2] - 1) break;
  }
  return { ok:false };
}

// ---------------------------------------------------------------------
// player state + movement
// ---------------------------------------------------------------------
