// ============================================================
// mat4.js
// ============================================================
"use strict";

function mat4Perspective(fovyRad, aspect, near, far){
  const f = 1.0 / Math.tan(fovyRad/2);
  const out = new Float32Array(16);
  out[0]=f/aspect; out[5]=f;
  out[10]=(far+near)/(near-far); out[11]=-1;
  out[14]=(2*far*near)/(near-far);
  return out;
}
function mat4LookDir(eye, forward, worldUp){
  const zaxis = V.normalize([-forward[0],-forward[1],-forward[2]]); // camera-space +z = backward
  const xaxis = V.normalize(V.cross(worldUp, zaxis));
  const yaxis = V.cross(zaxis, xaxis);
  const out = new Float32Array(16);
  out[0]=xaxis[0]; out[1]=yaxis[0]; out[2]=zaxis[0]; out[3]=0;
  out[4]=xaxis[1]; out[5]=yaxis[1]; out[6]=zaxis[1]; out[7]=0;
  out[8]=xaxis[2]; out[9]=yaxis[2]; out[10]=zaxis[2]; out[11]=0;
  out[12]=-V.dot(xaxis,eye); out[13]=-V.dot(yaxis,eye); out[14]=-V.dot(zaxis,eye); out[15]=1;
  return out;
}
function mat4Multiply(a,b){
  const out = new Float32Array(16);
  for (let c=0;c<4;c++){
    for (let r=0;r<4;r++){
      let sum=0;
      for (let k=0;k<4;k++) sum += a[k*4+r]*b[c*4+k];
      out[c*4+r]=sum;
    }
  }
  return out;
}

// ---------------------------------------------------------------------
// procedural textures (drawn with canvas 2d, no external files needed)
// ---------------------------------------------------------------------
