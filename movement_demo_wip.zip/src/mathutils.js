// ============================================================
// mathutils.js
// ============================================================
"use strict";

const V = {
  add:(a,b)=>[a[0]+b[0],a[1]+b[1],a[2]+b[2]],
  sub:(a,b)=>[a[0]-b[0],a[1]-b[1],a[2]-b[2]],
  scale:(a,s)=>[a[0]*s,a[1]*s,a[2]*s],
  cross:(a,b)=>[a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]],
  dot:(a,b)=>a[0]*b[0]+a[1]*b[1]+a[2]*b[2],
  length:(a)=>Math.hypot(a[0],a[1],a[2]),
  normalize:(a)=>{ const l=V.length(a)||1; return [a[0]/l,a[1]/l,a[2]/l]; },
};

// Rotate a local-space vector by euler angles given in degrees, applied in
// the fixed order roll(X) -> pitch(Y) -> yaw(Z). Used for both point offsets
// (editor entity corners) and normals (same rotation, just no translation
// afterwards) -- see editor.js: buildEntityBrush().
function rotateEuler(v, rotDeg){
  const rx = rotDeg[0]*Math.PI/180, ry = rotDeg[1]*Math.PI/180, rz = rotDeg[2]*Math.PI/180;
  let [x,y,z] = v;
  // roll around X
  let cx=Math.cos(rx), sx=Math.sin(rx);
  let y1 = y*cx - z*sx, z1 = y*sx + z*cx;
  y = y1; z = z1;
  // pitch around Y
  let cy=Math.cos(ry), sy=Math.sin(ry);
  let x2 = x*cy + z*sy, z2 = -x*sy + z*cy;
  x = x2; z = z2;
  // yaw around Z
  let cz=Math.cos(rz), sz=Math.sin(rz);
  let x3 = x*cz - y*sz, y3 = x*sz + y*cz;
  x = x3; y = y3;
  return [x,y,z];
}

// ---------------------------------------------------------------------
// movement tuning constants (source/quake-style, in "inches")
// ---------------------------------------------------------------------
