// ============================================================
// webgl_setup.js
// ============================================================
"use strict";

const canvas = document.getElementById("glcanvas");
const gl = canvas.getContext("webgl") || canvas.getContext("experimental-webgl");
if (!gl) {
  alert("WebGL is not available in this browser.");
}
gl.enable(gl.DEPTH_TEST);
gl.disable(gl.CULL_FACE); // avoid winding-order invisible-face bugs while iterating on map geometry
gl.clearColor(0.55, 0.62, 0.68, 1.0);

function compileShader(src, type){
  const sh = gl.createShader(type);
  gl.shaderSource(sh, src);
  gl.compileShader(sh);
  if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)){
    console.error(gl.getShaderInfoLog(sh));
    throw new Error("shader compile failed: " + gl.getShaderInfoLog(sh));
  }
  return sh;
}
function makeProgram(vsSrc, fsSrc){
  const vs = compileShader(vsSrc, gl.VERTEX_SHADER);
  const fs = compileShader(fsSrc, gl.FRAGMENT_SHADER);
  const prog = gl.createProgram();
  gl.attachShader(prog, vs);
  gl.attachShader(prog, fs);
  gl.linkProgram(prog);
  if (!gl.getProgramParameter(prog, gl.LINK_STATUS)){
    console.error(gl.getProgramInfoLog(prog));
    throw new Error("program link failed");
  }
  return prog;
}

const mainVS = `
  attribute vec3 aPos;
  attribute vec2 aUV;
  attribute float aShade;
  uniform mat4 uViewProj;
  uniform vec3 uCamPos;
  varying vec2 vUV;
  varying float vShade;
  varying float vDist;
  void main(){
    gl_Position = uViewProj * vec4(aPos, 1.0);
    vUV = aUV;
    vShade = aShade;
    vDist = length(aPos - uCamPos);
  }
`;
const mainFS = `
  precision mediump float;
  varying vec2 vUV;
  varying float vShade;
  varying float vDist;
  uniform sampler2D uTex;
  uniform vec3 uFogColor;
  uniform float uFogEnabled;
  void main(){
    vec4 texColor = texture2D(uTex, vUV);
    vec3 lit = texColor.rgb * vShade;
    float fog = clamp((vDist - 600.0) / 2600.0, 0.0, 1.0) * uFogEnabled;
    vec3 finalColor = mix(lit, uFogColor, fog);
    gl_FragColor = vec4(finalColor, 1.0);
  }
`;
const lineVS = `
  attribute vec3 aPos;
  uniform mat4 uViewProj;
  void main(){ gl_Position = uViewProj * vec4(aPos, 1.0); }
`;
const lineFS = `
  precision mediump float;
  uniform vec3 uColor;
  void main(){ gl_FragColor = vec4(uColor, 1.0); }
`;

const mainProg = makeProgram(mainVS, mainFS);
const lineProg = makeProgram(lineVS, lineFS);

const mainAttrib = {
  pos: gl.getAttribLocation(mainProg, "aPos"),
  uv: gl.getAttribLocation(mainProg, "aUV"),
  shade: gl.getAttribLocation(mainProg, "aShade"),
};
const mainUniform = {
  viewProj: gl.getUniformLocation(mainProg, "uViewProj"),
  camPos: gl.getUniformLocation(mainProg, "uCamPos"),
  tex: gl.getUniformLocation(mainProg, "uTex"),
  fogColor: gl.getUniformLocation(mainProg, "uFogColor"),
  fogEnabled: gl.getUniformLocation(mainProg, "uFogEnabled"),
};
const lineAttrib = { pos: gl.getAttribLocation(lineProg, "aPos") };
const lineUniform = {
  viewProj: gl.getUniformLocation(lineProg, "uViewProj"),
  color: gl.getUniformLocation(lineProg, "uColor"),
};

// ---------------------------------------------------------------------
// mat4 helpers (column-major, standard WebGL layout)
// ---------------------------------------------------------------------
