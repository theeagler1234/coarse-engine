# movement test chamber — source

There are two ways to run this:

## 1. Just play it
Open **`movement_demo.html`** (in the folder root) directly in a browser —
double-click it, or drag it into a browser window. It works fully offline
via `file://`, no server needed. This is a single self-contained file with
all the code inlined.

## 2. Read/edit the source
The `src/` folder has the exact same code split into the logical files it's
organized into conceptually:

| file                 | contents                                              |
|----------------------|--------------------------------------------------------|
| `mathutils.js`       | tiny vec3 helpers + euler rotation helper             |
| `constants.js`       | movement + editor tuning constants                     |
| `webgl_setup.js`     | WebGL context, shader compiling, program setup        |
| `mat4.js`            | perspective/view matrix math                           |
| `textures.js`        | procedurally-drawn textures (no external image files) |
| `brushes.js`         | brush/face builder helpers (box + ramp geometry)       |
| `map.js`             | the actual test map (brush placement)                  |
| `geometry_upload.js` | turns brush data into GPU buffers, batched by texture |
| `collision.js`       | plane-based push-out collision + ground probing        |
| `player.js`          | player state, friction/accelerate, crouch, physics step|
| `editor.js`          | in-game map editor: entities, picking, save/load, UI  |
| `input.js`           | keyboard/mouse/pointer-lock/UI wiring                  |
| `render.js`          | per-frame draw calls                                    |
| `main.js`            | the main loop + HUD updates                             |

Open **`src/index.html`** to run the split version — it loads all the
`.js` files above via plain `<script src="...">` tags in dependency order.
Because none of them are ES modules, they all share one global scope, same
as if it were one file — that's what lets `player.js` reference things
defined in `collision.js`, etc.

Both versions run the exact same logic (verified against each other) — the
single file is just `src/*.js` concatenated in that same order and inlined
into one `<script>` tag.

## What changed since the first version you tried
- **Speed you couldn't lose / friction never applying**: the "am I on the
  ground" check was being derived from whether the collision solver had to
  push the player out *this exact physics substep*. A player resting
  exactly on the floor has zero penetration by design, so that check
  flickered true/false from one substep to the next, and the *last*
  substep in a frame almost always landed on "false" — friction (which only
  runs while grounded) silently never fired. Ground state is now decided by
  a small dedicated downward probe instead, run once per frame, so it's
  stable.
- **Jump not firing**: same root cause — jump is also gated on "grounded",
  so it inherited the same bug.
- **Crouch**: added — hold Ctrl. Lowers your eye height and hitbox, roughly
  halves your top speed, and won't let you stand back up if something's
  directly overhead (it checks for room before uncrouching).

## Update: cursor-stuck-after-closing-tab, and Ctrl+W closing the game
- **Cursor getting stuck hidden (needed a system restart)**: the page was
  only releasing the mouse pointer lock reactively, in response to the
  browser's own `pointerlockchange` event. On some browser/OS combinations
  that event doesn't reliably fire when the tab is closed or loses focus,
  which can leave the pointer lock (and hidden cursor) stuck. Fixed by
  proactively calling `document.exitPointerLock()` on `visibilitychange`,
  `blur`, `pagehide`, and `beforeunload`, plus handling `pointerlockerror`.
- **Holding Ctrl to crouch while moving forward closed the tab (Ctrl+W)**:
  this one has a hard browser-level limit worth knowing about — Chrome
  deliberately refuses to let *any* page block reserved shortcuts like
  Ctrl+W/Ctrl+T/Ctrl+N via `preventDefault()`, for anti-spoofing reasons.
  No amount of JS can override that in Chrome specifically. `preventDefault`
  is still called on Ctrl combos (it genuinely helps in Firefox/Safari), but
  the real fix is `c` now works as an equal alternate crouch bind alongside
  Ctrl, so crouch-while-holding-W no longer has to route through Ctrl+W at
  all.

## Update: in-game map editor (`n` then `p`)
Added a built-in editor for placing your own geometry into the test chamber
and saving/loading it as JSON. `n` toggles noclip as before; `p` toggles the
editor and force-enables noclip if it wasn't already on (so the intended
flow really is "n, then p", but pressing p alone works too). Turning noclip
back off with `n` always closes the editor as well.

**What you can do:**
- **Select**: crosshair-hover highlights whatever brush you're looking at
  (cyan outline); left-click to select it (orange outline). Only brushes you
  placed are selectable for editing — the base test chamber's geometry is
  read-only for move/rotate/resize, though it can still be repainted.
- **Paint**: `Alt`+click any face (yours or the base map's) to apply the
  current palette texture to just that face. `,` / `.` cycle the palette
  (floor / wall / hazard / crate).
- **Move (grab)**: `g` toggles grab on the selected brush — it follows a
  point out in front of your camera; scroll to push it closer/farther;
  click or `g` again to drop it.
- **Rotate**: `r` toggles rotate mode — mouse now spins the brush (X move
  = yaw, Y move = pitch, hold Ctrl for roll) instead of the camera; `r`
  again to release and get your look-around back.
- **Stretch**: `t` toggles stretch mode — `1`/`2`/`3` pick the local X/Y/Z
  axis, scroll grows/shrinks the brush along it (from its center).
- **Create/delete**: `v` spawns a new box 160 units in front of you (shift+v
  for a ramp); `Delete`/`Backspace` removes the selected brush.
- **Save/load**: the panel's buttons save your placed brushes to a `.json`
  file, or load one back in. Loading replaces your current brushes but
  leaves the base test chamber alone, so a saved file is just "the stuff you
  built," layered back on top on load.

**How it's implemented, briefly:** editor brushes are plain data (position,
size, euler rotation, one texture per face) rebuilt into real brush geometry
any time they change, and pushed into the same `brushes` array the static
map already lives in — so collision, rendering, and now picking all treat
your creations exactly like part of the level, no separate code paths.
Picking is an exact ray-vs-convex-brush test against each brush's own
collision planes (rather than a bounding-box approximation), which is also
what makes rotated brushes pick and paint correctly. One known simplification:
face UVs use simple dominant-axis planar projection, so a texture on a brush
rotated to an odd angle will look a bit stretched/skewed rather than
perfectly tiled — acceptable for a test-chamber editor, but worth knowing.
