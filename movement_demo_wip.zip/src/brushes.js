// ============================================================
// brushes.js
// ============================================================
"use strict";

const lightDir = V.normalize([0.45, 0.55, 0.75]);
function shadeForNormal(n){
  const d = Math.max(V.dot(n, lightDir), 0);
  return Math.min(1, 0.38 + 0.62*d);
}
function computeUV(p, n, tileSize){
  const an = [Math.abs(n[0]), Math.abs(n[1]), Math.abs(n[2])];
  if (an[2] >= an[0] && an[2] >= an[1]) return [p[0]/tileSize, p[1]/tileSize];
  if (an[0] >= an[1] && an[0] >= an[2]) return [p[1]/tileSize, p[2]/tileSize];
  return [p[0]/tileSize, p[2]/tileSize];
}

// `slot` is a stable per-face name (e.g. "top", "east", "slope"...) used by
// the editor to know which part of an entity's per-face texture map a given
// face corresponds to, so painting survives rebuilds (resize/rotate/move all
// reconstruct faces from scratch -- see editor.js: buildEntityBrush()).
function faceQuad(a,b,c,d, normal, tex, slot){ return {verts:[a,b,c,d], normal, tex, slot}; }
function faceTri(a,b,c, normal, tex, slot){ return {verts:[a,b,c], normal, tex, slot}; }

// A brush's planes are derived directly from its faces (one plane per face,
// same order, same object reference attached as `.face`) rather than built
// separately. This guarantees planes[i] <-> faces[i] correspondence, which
// the editor's ray-vs-brush picker (editor.js: raycastBrush()) relies on to
// report exactly which face was hit.
function planeFromFace(face){
  return { n: face.normal, d: V.dot(face.normal, face.verts[0]), face };
}

// Resolves a per-face texture, given either a plain string (applied to every
// slot, for a uniformly-textured brush) or an object keyed by slot name (for
// per-face texturing, as used by editor entities).
function resolveFaceTex(texOrSides, slot){
  if (typeof texOrSides === "string") return texOrSides;
  return (texOrSides && texOrSides[slot]) || Object.values(texOrSides)[0];
}

function makeBoxBrush(min, max, texOrSides){
  const sides = (typeof texOrSides === "string")
    ? {top:texOrSides,bottom:texOrSides,north:texOrSides,south:texOrSides,east:texOrSides,west:texOrSides}
    : texOrSides;
  const [x0,y0,z0] = min, [x1,y1,z1] = max;
  const p = {
    A:[x0,y0,z0], B:[x1,y0,z0], C:[x1,y1,z0], D:[x0,y1,z0],
    E:[x0,y0,z1], F:[x1,y0,z1], G:[x1,y1,z1], H:[x0,y1,z1],
  };
  const faces = [
    faceQuad(p.E,p.F,p.G,p.H, [0,0,1], sides.top, "top"),
    faceQuad(p.B,p.A,p.D,p.C, [0,0,-1], sides.bottom, "bottom"),
    faceQuad(p.F,p.B,p.C,p.G, [1,0,0], sides.east, "east"),
    faceQuad(p.A,p.E,p.H,p.D, [-1,0,0], sides.west, "west"),
    faceQuad(p.C,p.D,p.H,p.G, [0,1,0], sides.north, "north"),
    faceQuad(p.A,p.B,p.F,p.E, [0,-1,0], sides.south, "south"),
  ];
  const planes = faces.map(planeFromFace);
  return { faces, planes, min, max };
}

// ramp rising along +X, flat bottom, from z0 (at x0) up to z1 (at x1)
function makeRampX(x0,x1,y0,y1,z0,z1, texOrSlots){
  const t = (slot)=>resolveFaceTex(texOrSlots, slot);
  const A=[x0,y0,z0], B=[x1,y0,z0], C=[x1,y1,z0], D=[x0,y1,z0];
  const E=[x1,y0,z1], F=[x1,y1,z1];
  const slopeN = V.normalize(V.cross(V.sub(E,A), V.sub(D,A)));
  const faces = [
    faceQuad(A,B,C,D, [0,0,-1], t("bottom"), "bottom"),      // bottom
    faceQuad(A,E,F,D, slopeN, t("slope"), "slope"),           // sloped top surface
    faceQuad(B,C,F,E, [1,0,0], t("backwall"), "backwall"),    // back wall (high end)
    faceTri(A,B,E, [0,-1,0], t("sideA"), "sideA"),             // side y0
    faceTri(D,F,C, [0,1,0], t("sideB"), "sideB"),              // side y1
  ];
  const planes = faces.map(planeFromFace);
  return { faces, planes, min:[x0,y0,z0], max:[x1,y1,z1] };
}

// ramp rising along +Y, flat bottom, from z0 (at y0) up to z1 (at y1)
function makeRampY(x0,x1,y0,y1,z0,z1, texOrSlots){
  const t = (slot)=>resolveFaceTex(texOrSlots, slot);
  const A=[x0,y0,z0], B=[x1,y0,z0], C=[x1,y1,z0], D=[x0,y1,z0];
  const E=[x0,y1,z1], F=[x1,y1,z1];
  const slopeN = V.normalize(V.cross(V.sub(B,A), V.sub(E,A)));
  const faces = [
    faceQuad(A,B,C,D, [0,0,-1], t("bottom"), "bottom"),        // bottom
    faceQuad(A,B,F,E, slopeN, t("slope"), "slope"),             // sloped top surface
    faceQuad(D,C,F,E, [0,1,0], t("backwall"), "backwall"),      // back wall (high end)
    faceTri(A,E,D, [-1,0,0], t("sideA"), "sideA"),               // side x0
    faceTri(B,C,F, [1,0,0], t("sideB"), "sideB"),                // side x1
  ];
  const planes = faces.map(planeFromFace);
  return { faces, planes, min:[x0,y0,z0], max:[x1,y1,z1] };
}

// ---------------------------------------------------------------------
// map definition
// ---------------------------------------------------------------------
