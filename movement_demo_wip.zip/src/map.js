// ============================================================
// map.js
// ============================================================
"use strict";

const brushes = [];

// One spec per base-chamber piece, stashed here so editor.js (loaded later)
// can wrap each already-built brush into a real, editable entity once it's
// ready -- see editor.js: wrapBaseBrush()/initBaseEntities(). This file
// can't do that wrapping itself: it runs (and needs `brushes` filled in)
// before editor.js has loaded.
const baseBrushSpecs = [];

function addBox(min,max,tex){
  const b = makeBoxBrush(min,max,tex);
  brushes.push(b);
  baseBrushSpecs.push({ brush:b, type:"box", min:min.slice(), max:max.slice(), tex });
  return b;
}
function addRampX(x0,x1,y0,y1,z0,z1,tex){
  const b = makeRampX(x0,x1,y0,y1,z0,z1,tex);
  brushes.push(b);
  baseBrushSpecs.push({ brush:b, type:"ramp", min:[x0,y0,z0], max:[x1,y1,z1], tex });
  return b;
}
function addRampY(x0,x1,y0,y1,z0,z1,tex){
  const b = makeRampY(x0,x1,y0,y1,z0,z1,tex);
  brushes.push(b);
  baseBrushSpecs.push({ brush:b, type:"rampy", min:[x0,y0,z0], max:[x1,y1,z1], tex });
  return b;
}

// ground
addBox([-1500,-1500,-32],[1500,1500,0], {top:"floor",bottom:"floor",north:"wall",south:"wall",east:"wall",west:"wall"});

// boundary walls
addBox([-1500,-1500,0],[1500,-1470,600], "wall");
addBox([-1500,1470,0],[1500,1500,600], "wall");
addBox([-1500,-1500,0],[-1470,1500,600], "wall");
addBox([1470,-1500,0],[1500,1500,600], "wall");

// --- staircase (tests step-up movement), 8 steps of 8 units rising east ---
for (let i=0;i<8;i++){
  const x0 = -1200 + i*48;
  addBox([x0,-700,0],[x0+48,-500, 8*(i+1)], {top:"floor",bottom:"floor",north:"wall",south:"wall",east:"wall",west:"wall"});
}

// --- long shallow ramp up to a platform (surf/ramp-walk test) ---
addRampX(-1200,-800,-300,-100,0,192,"hazard");
addBox([-800,-300,176],[-500,-100,192], {top:"floor",bottom:"wall",north:"wall",south:"wall",east:"wall",west:"wall"}); // platform at top of ramp

// --- steep ramp against a wall (surf test) ---
addRampY(-200,200,600,900,0,340,"hazard");
addBox([-200,900,0],[200,930,340],"wall"); // backstop wall the steep ramp leans into

// --- scattered crates for jump/collision variety ---
addBox([200,-200,0],[264,-136,64],"crate");
addBox([320,-260,0],[400,-180,96],"crate");
addBox([200,-320,0],[248,-268,40],"crate");

// --- raised platform with a gap, for bunnyhop distance testing ---
addBox([600,-400,0],[900,-100,128], {top:"floor",bottom:"wall",north:"wall",south:"wall",east:"wall",west:"wall"});
addBox([1050,-400,0],[1350,-100,128], {top:"floor",bottom:"wall",north:"wall",south:"wall",east:"wall",west:"wall"});
// gap between x=900 and x=1050 (150 units) must be crossed by bunnyhopping

// --- a pit to test falling / landing ---
addBox([-900,300,-256],[-500,700,-64], {top:"floor",bottom:"floor",north:"wall",south:"wall",east:"wall",west:"wall"});

// ---------------------------------------------------------------------
// upload brush geometry to GPU, batched per texture
// ---------------------------------------------------------------------
