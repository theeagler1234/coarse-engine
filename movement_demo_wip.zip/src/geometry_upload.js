// ============================================================
// geometry_upload.js
// ============================================================
"use strict";

const TILE = 64;
let buffersByTexture = {}; // name -> {pos:[], uv:[], shade:[]}
let lineSegments = []; // flat array of [x,y,z] pairs for debug wireframe

let glBuffers = {}; // name -> {posBuf, uvBuf, shadeBuf, count, texture}
let lineBuf = null;
let lineVertCount = 0;

function pushFace(face){
  const bucket = buffersByTexture[face.tex] || (buffersByTexture[face.tex] = {pos:[],uv:[],shade:[]});
  const shade = shadeForNormal(face.normal);
  const verts = face.verts;
  const uvs = verts.map(v => computeUV(v, face.normal, TILE));
  function pushVert(i){
    bucket.pos.push(verts[i][0], verts[i][1], verts[i][2]);
    bucket.uv.push(uvs[i][0], uvs[i][1]);
    bucket.shade.push(shade);
  }
  if (verts.length === 4){
    pushVert(0); pushVert(1); pushVert(2);
    pushVert(0); pushVert(2); pushVert(3);
  } else {
    pushVert(0); pushVert(1); pushVert(2);
  }
  for (let i=0;i<verts.length;i++){
    const a = verts[i], b = verts[(i+1)%verts.length];
    lineSegments.push(a[0],a[1],a[2], b[0],b[1],b[2]);
  }
}

// Rebuilds every GPU buffer from the current contents of the global
// `brushes` array. Called once at startup, and again by the editor any time
// a brush is added, removed, moved, resized, rotated, or repainted -- the
// map is small enough that a full re-upload per edit is cheap and much
// simpler than trying to patch individual buffers in place.
function rebuildGeometry(){
  buffersByTexture = {};
  lineSegments = [];

  for (const brush of brushes){
    for (const face of brush.faces) pushFace(face);
  }

  // drop old GPU buffers before allocating new ones
  for (const name in glBuffers){
    const b = glBuffers[name];
    gl.deleteBuffer(b.posBuf); gl.deleteBuffer(b.uvBuf); gl.deleteBuffer(b.shadeBuf);
  }
  glBuffers = {};
  for (const name in buffersByTexture){
    const b = buffersByTexture[name];
    const posBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, posBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(b.pos), gl.STATIC_DRAW);
    const uvBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, uvBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(b.uv), gl.STATIC_DRAW);
    const shadeBuf = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, shadeBuf);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(b.shade), gl.STATIC_DRAW);
    glBuffers[name] = { posBuf, uvBuf, shadeBuf, count: b.pos.length/3, texture: TEX[name] };
  }

  if (lineBuf) gl.deleteBuffer(lineBuf);
  lineBuf = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, lineBuf);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(lineSegments), gl.STATIC_DRAW);
  lineVertCount = lineSegments.length/3;
}

rebuildGeometry();

// ---------------------------------------------------------------------
// collision
// ---------------------------------------------------------------------
