// ============================================================
// constants.js
// ============================================================
"use strict";

const GRAVITY        = 800;
const MAX_SPEED       = 320;   // sv_maxspeed
const CROUCH_SPEED    = 140;   // max ground speed while crouched
const ACCELERATE      = 10;    // sv_accelerate (ground)
const STOP_SPEED      = 100;
const FRICTION        = 4;
const JUMP_SPEED      = 268;   // ~45 unit jump height
const HALF_XY         = 16;    // player AABB half-width/depth (constant)
const STAND_HALF_Z    = 36;    // half-height standing (72 tall)
const CROUCH_HALF_Z   = 18;    // half-height crouched (36 tall)
const STAND_EYE       = 28;    // eye offset from AABB center, standing
const CROUCH_EYE      = 10;    // eye offset from AABB center, crouched
const STEP_HEIGHT      = 18;
const NOCLIP_SPEED    = 600;
const GROUND_PROBE    = 2;     // how far below the player we probe for "on ground"

let airAccelerate = 12; // tunable live via slider

// ---------------------------------------------------------------------
// map editor tuning
// ---------------------------------------------------------------------
const EDITOR_RAY_DIST      = 4000;  // max raycast distance for hover/select/paint
const EDITOR_SPAWN_DIST    = 160;   // how far in front of camera a new brush spawns
const EDITOR_DEFAULT_SIZE  = 64;    // default cube edge length for a spawned box
const EDITOR_GRAB_MIN      = 32;    // closest an object can be held from the camera
const EDITOR_GRAB_MAX      = 1000;  // farthest an object can be held from the camera
const EDITOR_GRAB_WHEEL    = 20;    // grab distance change per wheel notch
const EDITOR_STRETCH_WHEEL = 8;     // size change (units) per wheel notch while stretching
const EDITOR_STRETCH_MIN   = 8;     // smallest allowed dimension on any axis
const EDITOR_ROTATE_SENS   = 0.25;  // degrees of rotation per pixel of mouse movement
const EDITOR_PALETTE       = ["floor","wall","hazard","crate","dirt","adobe"]; // paintable textures

// ---------------------------------------------------------------------
// WebGL setup
// ---------------------------------------------------------------------
