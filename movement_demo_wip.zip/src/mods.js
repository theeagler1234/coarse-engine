// ============================================================
// mods.js -- user-written JS "mod scripts" embedded in the map JSON
// ============================================================
// Data model: a script is {id, name, code} (plain JS source, as text).
// serializeMap() (editor.js) stores them as {id, name, code_b64} -- code
// run through utf8ToBase64() -- so a map file with mods attached is still
// just one self-contained JSON file. Nothing here ever auto-runs a script
// just because a map was loaded: loading only decodes and lists scripts
// (see loadScriptsFromSave below), running them is always an explicit
// "run scripts" click, same trust model as opening any other downloaded
// script file.
//
// Each script runs in its OWN function scope (via `new Function`), so a
// `let`/`const`/`var` a script declares at its own top level can never
// collide with another script's -- the only way two scripts can see each
// other at all is the shared `API.bus`, on purpose. See mod_docs.md for
// the full API reference -- keep that file in sync with buildModAPI()
// below if you change this.
"use strict";

const editorScripts = []; // {id, name, code}
let scriptIdCounter = 0;
function genScriptId(){ return "script_" + (++scriptIdCounter) + "_" + Math.random().toString(36).slice(2, 7); }

// ---------------------------------------------------------------------
// cross-mod event bus -- the one intentional shared surface between
// otherwise-isolated scripts (e.g. an economy mod emitting "gold-changed"
// that an inventory mod listens for).
// ---------------------------------------------------------------------
const modBus = {};
function busEmit(event, payload){
  const hs = modBus[event];
  if (!hs) return;
  for (const h of hs.slice()) {
    try { h(payload); } catch (err) { modLog("bus:" + event, "handler error: " + err.message); }
  }
}
function busOn(event, handler){
  if (typeof handler !== "function") return;
  (modBus[event] || (modBus[event] = [])).push(handler);
}

// ---------------------------------------------------------------------
// per-frame / per-key hooks, tagged with the script id that registered
// them so a script can be cleanly unhooked when stopped or re-run.
// ---------------------------------------------------------------------
const modUpdateHooks = [];  // {scriptId, fn(dt)}
const modKeyDownHooks = []; // {scriptId, fn(code)}
const modKeyUpHooks = [];   // {scriptId, fn(code)}
const modStorage = {};      // scriptId -> {key: value}, namespaced per script

function unhookScript(scriptId){
  for (let i = modUpdateHooks.length - 1; i >= 0; i--) if (modUpdateHooks[i].scriptId === scriptId) modUpdateHooks.splice(i, 1);
  for (let i = modKeyDownHooks.length - 1; i >= 0; i--) if (modKeyDownHooks[i].scriptId === scriptId) modKeyDownHooks.splice(i, 1);
  for (let i = modKeyUpHooks.length - 1; i >= 0; i--) if (modKeyUpHooks[i].scriptId === scriptId) modKeyUpHooks.splice(i, 1);
}

// ---------------------------------------------------------------------
// the API object handed to each script -- this (plus `console`) is the
// ONLY thing a script gets automatically; everything else it needs it
// must ask for through here, which is what keeps scripts from stepping
// on the engine's own internals or on each other. See mod_docs.md.
// ---------------------------------------------------------------------
function buildModAPI(script){
  const sid = script.id;
  if (!modStorage[sid]) modStorage[sid] = {};
  const store = modStorage[sid];
  return {
    version: 1,
    scriptName: script.name,
    on(event, handler){
      if (typeof handler !== "function") return;
      if (event === "update") modUpdateHooks.push({ scriptId: sid, fn: handler });
      else if (event === "keydown") modKeyDownHooks.push({ scriptId: sid, fn: handler });
      else if (event === "keyup") modKeyUpHooks.push({ scriptId: sid, fn: handler });
      else modLog(script.name, `on(): unknown event "${event}" (use "update", "keydown", or "keyup")`);
    },
    player: {
      pos(){ return player.pos.slice(); },
      vel(){ return player.vel.slice(); },
      yaw(){ return player.yaw; },
      pitch(){ return player.pitch; },
      onGround(){ return player.onGround; },
      crouched(){ return player.crouched; },
      noclip(){ return player.noclip; },
    },
    world: {
      spawnBox(pos, size, tex){
        const ent = createEntity({ type: "box", pos, size, rot: [0, 0, 0], faceTex: expandFaceTex("box", tex || "crate") });
        return ent.id;
      },
      spawnRamp(pos, size, tex, axis){
        const type = axis === "y" ? "rampy" : "ramp";
        const ent = createEntity({ type, pos, size, rot: [0, 0, 0], faceTex: expandFaceTex(type, tex || "hazard") });
        return ent.id;
      },
      remove(entityId){
        const ent = editorEntities.find(e => e.id === entityId);
        if (ent) removeEntity(ent);
      },
      exists(entityId){
        return editorEntities.some(e => e.id === entityId);
      },
    },
    store: {
      get(key, fallback){ return (key in store) ? store[key] : fallback; },
      set(key, value){ store[key] = value; },
      all(){ return JSON.parse(JSON.stringify(store)); },
    },
    bus: { emit: busEmit, on: busOn },
    log(msg){ modLog(script.name, String(msg)); },
  };
}

function modLog(scriptName, msg){
  const line = `[${scriptName}] ${msg}`;
  console.log(line);
  pushModConsoleLine(line);
}

function runScript(script){
  unhookScript(script.id); // re-running (e.g. after an edit) replaces old hooks cleanly, no duplicates
  const api = buildModAPI(script);
  try {
    const fn = new Function("API", "console", script.code);
    fn(api, console);
    modLog(script.name, "loaded");
  } catch (err){
    modLog(script.name, "ERROR: " + err.message);
  }
}
function runAllScripts(){ for (const s of editorScripts) runScript(s); }
function stopAllScripts(){ for (const s of editorScripts) unhookScript(s.id); modLog("mods", "all scripts stopped"); }

function modsUpdate(dt){
  for (const h of modUpdateHooks.slice()) {
    try { h.fn(dt); } catch (err){ modLog("update", "hook error: " + err.message); }
  }
}
function modsKeyDown(code){
  for (const h of modKeyDownHooks.slice()) {
    try { h.fn(code); } catch (err){ modLog("keydown", "hook error: " + err.message); }
  }
}
function modsKeyUp(code){
  for (const h of modKeyUpHooks.slice()) {
    try { h.fn(code); } catch (err){ modLog("keyup", "hook error: " + err.message); }
  }
}

// called by editor.js: loadMapFromObject() after decoding a save file.
// Deliberately does NOT run anything -- see file header.
function loadScriptsFromSave(list){
  stopAllScripts();
  editorScripts.length = 0;
  for (const s of list) {
    if (!s || typeof s.code_b64 !== "string") continue;
    let code;
    try { code = base64ToUtf8(s.code_b64); } catch (err) { continue; }
    editorScripts.push({ id: s.id || genScriptId(), name: (s.name || "script").slice(0, 80), code });
  }
  refreshScriptListUI();
}

// ---------------------------------------------------------------------
// UI: script manager modal + on-screen mod console
// ---------------------------------------------------------------------
let openScriptId = null;

function refreshScriptListUI(){
  const listEl = document.getElementById("msList");
  if (!listEl) return;
  listEl.innerHTML = "";
  if (editorScripts.length === 0){
    const empty = document.createElement("div");
    empty.style.cssText = "color:var(--ink-dim); font-size:11px; padding:6px 2px;";
    empty.textContent = "no scripts yet -- click \"+ new script\" below.";
    listEl.appendChild(empty);
  }
  for (const s of editorScripts) {
    const row = document.createElement("div");
    row.className = "msRow" + (s.id === openScriptId ? " msRowActive" : "");
    const nameSpan = document.createElement("span");
    nameSpan.textContent = s.name;
    nameSpan.className = "msName";
    nameSpan.addEventListener("click", () => openScriptEditor(s.id));
    const delBtn = document.createElement("button");
    delBtn.textContent = "\u00d7";
    delBtn.title = "delete script";
    delBtn.className = "msDelBtn";
    delBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      if (!confirm(`delete script "${s.name}"?`)) return;
      unhookScript(s.id);
      const idx = editorScripts.indexOf(s);
      if (idx >= 0) editorScripts.splice(idx, 1);
      if (openScriptId === s.id) closeScriptEditor();
      refreshScriptListUI();
    });
    row.appendChild(nameSpan);
    row.appendChild(delBtn);
    listEl.appendChild(row);
  }
}

function openScriptEditor(id){
  const s = editorScripts.find(sc => sc.id === id);
  if (!s) return;
  openScriptId = id;
  document.getElementById("msEditorWrap").style.display = "block";
  document.getElementById("msEditorName").value = s.name;
  document.getElementById("msEditorCode").value = s.code;
  refreshScriptListUI();
}
function closeScriptEditor(){
  openScriptId = null;
  document.getElementById("msEditorWrap").style.display = "none";
  refreshScriptListUI();
}
function saveOpenScript(){
  const s = editorScripts.find(sc => sc.id === openScriptId);
  if (!s) return;
  s.name = (document.getElementById("msEditorName").value || "script").slice(0, 80);
  s.code = document.getElementById("msEditorCode").value;
  refreshScriptListUI();
}

function openScriptsModal(){
  document.getElementById("modScriptsModal").style.display = "flex";
  releasePointerLockSafely(); // typing needs a normal cursor, not pointer-lock
  refreshScriptListUI();
}
function closeScriptsModal(){
  document.getElementById("modScriptsModal").style.display = "none";
  closeScriptEditor();
}

function pushModConsoleLine(line){
  const el = document.getElementById("modConsole");
  if (!el) return;
  const row = document.createElement("div");
  row.textContent = line;
  el.appendChild(row);
  while (el.children.length > 200) el.removeChild(el.firstChild);
  el.scrollTop = el.scrollHeight;
  el.style.display = "block";
}

function initModsUI(){
  const btn = document.getElementById("epScripts");
  if (btn) btn.addEventListener("click", openScriptsModal);
  const closeBtn = document.getElementById("msCloseBtn");
  if (closeBtn) closeBtn.addEventListener("click", closeScriptsModal);
  const newBtn = document.getElementById("msNewBtn");
  if (newBtn) newBtn.addEventListener("click", () => {
    const name = (prompt("script name (e.g. \"inventory\", \"economy\"):", "new_script") || "").trim();
    if (!name) return;
    const s = { id: genScriptId(), name: name.slice(0, 80), code: `// ${name}\n// see mod_docs.md for the full API reference.\nAPI.log("hello from ${name}");\n\nAPI.on("update", (dt) => {\n  // runs every frame while this script is running\n});\n` };
    editorScripts.push(s);
    refreshScriptListUI();
    openScriptEditor(s.id);
  });
  const saveBtn = document.getElementById("msSaveBtn");
  if (saveBtn) saveBtn.addEventListener("click", saveOpenScript);
  const closeEditorBtn = document.getElementById("msEditorCloseBtn");
  if (closeEditorBtn) closeEditorBtn.addEventListener("click", () => { saveOpenScript(); closeScriptEditor(); });
  const runBtn = document.getElementById("msRunBtn");
  if (runBtn) runBtn.addEventListener("click", () => { saveOpenScript(); runAllScripts(); });
  const stopBtn = document.getElementById("msStopBtn");
  if (stopBtn) stopBtn.addEventListener("click", stopAllScripts);
  refreshScriptListUI();
}
initModsUI();
